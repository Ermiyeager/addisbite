package com.example.addisbite

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
