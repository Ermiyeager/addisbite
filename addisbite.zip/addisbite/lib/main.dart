import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'constants/app_constants.dart';
import 'providers/auth_provider.dart';
import 'providers/cart_provider.dart';
import 'providers/favorites_provider.dart';
import 'providers/order_provider.dart';
import 'providers/settings_provider.dart';
import 'screens/splash_screen.dart';
import 'services/storage_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  // Needed before using plugins (SharedPreferences) in main().
  WidgetsFlutterBinding.ensureInitialized();
  await StorageService.instance.init();

  // Create providers and load saved data before the first frame.
  final settings = SettingsProvider();
  final auth = AuthProvider();
  final cart = CartProvider();
  final favorites = FavoritesProvider();
  final orders = OrderProvider();

  await Future.wait([
    settings.load(),
    auth.load(),
    cart.load(),
    favorites.load(),
    orders.load(),
  ]);

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider<SettingsProvider>.value(value: settings),
        ChangeNotifierProvider<AuthProvider>.value(value: auth),
        ChangeNotifierProvider<CartProvider>.value(value: cart),
        ChangeNotifierProvider<FavoritesProvider>.value(value: favorites),
        ChangeNotifierProvider<OrderProvider>.value(value: orders),
      ],
      child: const AddisBiteApp(),
    ),
  );
}

class AddisBiteApp extends StatelessWidget {
  const AddisBiteApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Rebuilds when the user switches dark mode.
    final settings = context.watch<SettingsProvider>();

    return MaterialApp(
      title: AppConstants.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: settings.themeMode,
      home: const SplashScreen(),
    );
  }
}
