import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../providers/cart_provider.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';
import '../utils/validators.dart';
import '../widgets/cart_item_tile.dart';
import '../widgets/custom_button.dart';
import '../widgets/empty_state.dart';
import '../widgets/price_widget.dart';
import 'checkout_screen.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  final _promoFormKey = GlobalKey<FormState>();
  final _promoController = TextEditingController();
  String? _promoError;

  @override
  void dispose() {
    _promoController.dispose();
    super.dispose();
  }

  void _applyPromo() {
    setState(() => _promoError = null);
    if (!(_promoFormKey.currentState?.validate() ?? false)) return;

    final cart = context.read<CartProvider>();
    final error = cart.applyPromo(_promoController.text);
    if (error != null) {
      setState(() => _promoError = error);
      return;
    }
    FocusScope.of(context).unfocus();
    _promoController.clear();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(
          '${cart.appliedPromo?.code} applied. You save ${formatBirr(cart.discount)}.'),
    ));
  }

  Future<void> _confirmClear() async {
    final cart = context.read<CartProvider>();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Clear your cart?'),
        content: const Text('All items will be removed.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Clear cart'),
          ),
        ],
      ),
    );
    if (confirmed == true) cart.clear();
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final restaurant = cart.restaurant;

    return Scaffold(
      appBar: AppBar(
        title: const Text('My cart'),
        actions: [
          if (!cart.isEmpty)
            TextButton.icon(
              onPressed: _confirmClear,
              icon: const Icon(Icons.delete_sweep_outlined),
              label: const Text('Clear'),
            ),
        ],
      ),
      body: cart.isEmpty
          ? EmptyState(
              emoji: '🛒',
              title: 'Your cart is empty',
              message:
                  'Add a Doro Wat, a pizza or anything you are craving and it will show up here.',
              actionLabel: 'Browse food',
              onAction: () => Navigator.pop(context),
            )
          : Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                  children: [
                    if (restaurant != null)
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Text(restaurant.logoEmoji,
                            style: const TextStyle(fontSize: 30)),
                        title: Text(restaurant.name,
                            style: const TextStyle(fontWeight: FontWeight.w800)),
                        subtitle: Text(
                            '${restaurant.location} • ${restaurant.deliveryTimeLabel}'),
                        trailing: TextButton(
                          onPressed: () => openRestaurant(context, restaurant),
                          child: const Text('Add more'),
                        ),
                      ),
                    for (final item in cart.items) ...[
                      CartItemTile(item: item),
                      const SizedBox(height: 10),
                    ],
                    Text(
                      'Swipe an item left to remove it.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context)),
                    ),
                    const SizedBox(height: 16),
                    _FreeDeliveryProgress(cart: cart),
                    const SizedBox(height: 16),
                    _buildPromoSection(cart),
                    const SizedBox(height: 16),
                    _Summary(cart: cart),
                  ],
                ),
              ),
            ),
      bottomNavigationBar: cart.isEmpty
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
                child: CustomButton(
                  label: 'Go to checkout  •  ${formatBirr(cart.total)}',
                  icon: Icons.lock_rounded,
                  onPressed: () => pushScreen(context, const CheckoutScreen()),
                ),
              ),
            ),
    );
  }

  Widget _buildPromoSection(CartProvider cart) {
    final promo = cart.appliedPromo;
    if (promo != null) {
      return Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.flagGreen.withAlpha(30),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.flagGreen.withAlpha(90)),
        ),
        child: Row(
          children: [
            const Icon(Icons.check_circle_rounded, color: AppColors.flagGreen),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${promo.code} applied',
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(promo.description,
                      style: TextStyle(
                          fontSize: 12, color: AppColors.mutedOf(context))),
                ],
              ),
            ),
            IconButton(
              tooltip: 'Remove promo code',
              onPressed: cart.removePromo,
              icon: const Icon(Icons.close_rounded),
            ),
          ],
        ),
      );
    }

    final error = _promoError;
    return Form(
      key: _promoFormKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: TextFormField(
                  controller: _promoController,
                  textCapitalization: TextCapitalization.characters,
                  textInputAction: TextInputAction.done,
                  onFieldSubmitted: (_) => _applyPromo(),
                  decoration: const InputDecoration(
                    hintText: 'Promo code',
                    prefixIcon: Icon(Icons.local_offer_outlined),
                  ),
                  validator: Validators.promoCode,
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(onPressed: _applyPromo, child: const Text('Apply')),
            ],
          ),
          if (error != null)
            Padding(
              padding: const EdgeInsets.only(top: 6, left: 4),
              child: Text(error, style: const TextStyle(color: AppColors.error)),
            ),
          Padding(
            padding: const EdgeInsets.only(top: 6, left: 4),
            child: Text(
              'Try ADDIS10, WELCOME50 or HABESHA20',
              style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context)),
            ),
          ),
        ],
      ),
    );
  }
}

class _FreeDeliveryProgress extends StatelessWidget {
  final CartProvider cart;

  const _FreeDeliveryProgress({required this.cart});

  @override
  Widget build(BuildContext context) {
    final remaining = cart.amountToFreeDelivery;
    final progress =
        (cart.subtotal / AppConstants.freeDeliveryThreshold).clamp(0.0, 1.0).toDouble();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.meskelGold.withAlpha(35),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            remaining <= 0
                ? '🎉 You unlocked free delivery!'
                : 'Add ${formatBirr(remaining)} more for free delivery',
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: TweenAnimationBuilder<double>(
              tween: Tween<double>(end: progress),
              duration: const Duration(milliseconds: 500),
              builder: (context, value, child) => LinearProgressIndicator(
                value: value,
                minHeight: 8,
                color: AppColors.flagGreen,
                backgroundColor: Colors.white.withAlpha(120),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Summary extends StatelessWidget {
  final CartProvider cart;

  const _Summary({required this.cart});

  Widget _row(BuildContext context, String label, String value,
      {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Expanded(
            child: Text(label, style: TextStyle(color: AppColors.mutedOf(context))),
          ),
          Text(value,
              style: TextStyle(fontWeight: FontWeight.w700, color: color)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          _row(context, 'Subtotal (${cart.itemCount} items)',
              formatBirr(cart.subtotal)),
          _row(
            context,
            'Delivery fee',
            cart.deliveryFee == 0 ? 'Free' : formatBirr(cart.deliveryFee),
            color: cart.deliveryFee == 0 ? AppColors.flagGreen : null,
          ),
          if (cart.discount > 0)
            _row(
              context,
              'Discount (${cart.appliedPromo?.code})',
              '-${formatBirr(cart.discount)}',
              color: AppColors.flagGreen,
            ),
          const Divider(height: 24),
          Row(
            children: [
              Expanded(
                child: Text('Total',
                    style: Theme.of(context).textTheme.titleLarge),
              ),
              AnimatedPrice(
                amount: cart.total,
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  color: AppColors.accentOf(context),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
