import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../models/order.dart';
import '../providers/order_provider.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';
import '../widgets/custom_button.dart';
import '../widgets/empty_state.dart';
import '../widgets/tibeb_stripe.dart';
import 'main_shell.dart';
import 'order_tracking_screen.dart';

class OrderConfirmationScreen extends StatefulWidget {
  final String orderId;

  const OrderConfirmationScreen({super.key, required this.orderId});

  @override
  State<OrderConfirmationScreen> createState() =>
      _OrderConfirmationScreenState();
}

class _OrderConfirmationScreenState extends State<OrderConfirmationScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 900),
  );
  late final Animation<double> _scale =
      CurvedAnimation(parent: _controller, curve: Curves.elasticOut);

  @override
  void initState() {
    super.initState();
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _backToHome() {
    MainShell.goToTab(0);
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final order = context.watch<OrderProvider>().findById(widget.orderId);

    if (order == null) {
      return Scaffold(
        appBar: AppBar(),
        body: EmptyState(
          emoji: '🧐',
          title: 'Order not found',
          message: 'We could not find this order. Check your order history.',
          actionLabel: 'Back to home',
          onAction: _backToHome,
        ),
      );
    }

    final scheduled = order.scheduledFor;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: ListView(
              padding: const EdgeInsets.all(24),
              children: [
                const SizedBox(height: 24),
                Center(
                  child: ScaleTransition(
                    scale: _scale,
                    child: Container(
                      width: 120,
                      height: 120,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppColors.greenGradient,
                      ),
                      child: const Icon(Icons.check_rounded,
                          color: Colors.white, size: 72),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  'Order placed!',
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.headlineMedium,
                ),
                const SizedBox(height: 8),
                Text(
                  '${order.restaurantName} has received your order and will start cooking soon.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.mutedOf(context), height: 1.4),
                ),
                const SizedBox(height: 24),
                Container(
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    children: [
                      const TibebStripe(height: 10),
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            _Row(label: 'Order number', value: order.id),
                            _Row(label: 'Items', value: '${order.itemCount}'),
                            _Row(label: 'Payment', value: order.paymentMethod.label),
                            _Row(
                              label: 'Delivery',
                              value: scheduled == null
                                  ? 'About ${order.etaMinutes} min'
                                  : formatDateTime(scheduled),
                            ),
                            _Row(label: 'Deliver to', value: order.address.shortLabel),
                            const Divider(height: 24),
                            _Row(
                              label: 'Total paid',
                              value: formatBirr(order.total),
                              bold: true,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 28),
                CustomButton(
                  label: 'Track my order',
                  icon: Icons.delivery_dining_rounded,
                  onPressed: () => Navigator.of(context).pushReplacement(
                    buildRoute(OrderTrackingScreen(orderId: order.id)),
                  ),
                ),
                const SizedBox(height: 12),
                CustomButton(
                  label: 'Back to home',
                  variant: ButtonVariant.outline,
                  onPressed: _backToHome,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Row extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;

  const _Row({required this.label, required this.value, this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Text(label, style: TextStyle(color: AppColors.mutedOf(context))),
          ),
          const SizedBox(width: 12),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontWeight: bold ? FontWeight.w900 : FontWeight.w700,
                fontSize: bold ? 18 : 14,
                color: bold ? AppColors.accentOf(context) : null,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
