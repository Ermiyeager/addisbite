import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/order.dart';
import '../providers/order_provider.dart';
import '../widgets/empty_state.dart';
import '../widgets/order_card.dart';
import 'main_shell.dart';

class OrdersScreen extends StatelessWidget {
  const OrdersScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<OrderProvider>();
    final active = orders.activeOrders;
    final past = orders.pastOrders;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('My orders'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Active (${active.length})'),
              Tab(text: 'History (${past.length})'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _OrderList(
              orders: active,
              empty: EmptyState(
                emoji: '🛵',
                title: 'No active orders',
                message: 'When you place an order, you can follow it here step by step.',
                actionLabel: 'Find something to eat',
                onAction: () => MainShell.goToTab(0),
              ),
            ),
            _OrderList(
              orders: past,
              empty: const EmptyState(
                emoji: '🧾',
                title: 'No past orders yet',
                message: 'Your delivered and cancelled orders will appear here.',
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _OrderList extends StatelessWidget {
  final List<Order> orders;
  final Widget empty;

  const _OrderList({required this.orders, required this.empty});

  @override
  Widget build(BuildContext context) {
    if (orders.isEmpty) return empty;
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: orders.length,
      separatorBuilder: (context, index) => const SizedBox(height: 12),
      itemBuilder: (context, index) => OrderCard(order: orders[index]),
    );
  }
}
