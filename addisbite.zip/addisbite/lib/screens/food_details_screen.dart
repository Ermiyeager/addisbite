import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../data/mock_data.dart';
import '../models/food_item.dart';
import '../services/restaurant_service.dart';
import '../utils/cart_actions.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';
import '../widgets/cart_icon_button.dart';
import '../widgets/custom_button.dart';
import '../widgets/favorite_button.dart';
import '../widgets/food_card.dart';
import '../widgets/food_visual.dart';
import '../widgets/price_widget.dart';
import '../widgets/quantity_selector.dart';
import '../widgets/rating_widget.dart';

class FoodDetailsScreen extends StatefulWidget {
  final FoodItem food;
  final String? heroTag;

  const FoodDetailsScreen({super.key, required this.food, this.heroTag});

  @override
  State<FoodDetailsScreen> createState() => _FoodDetailsScreenState();
}

class _FoodDetailsScreenState extends State<FoodDetailsScreen> {
  int _quantity = 1;
  final List<FoodExtra> _selectedExtras = [];
  final TextEditingController _noteController = TextEditingController();

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  /// Live total: (base price + chosen extras) × quantity.
  double get _total {
    final extras =
        _selectedExtras.fold<double>(0, (sum, extra) => sum + extra.price);
    return (widget.food.price + extras) * _quantity;
  }

  void _toggleExtra(FoodExtra extra, bool selected) {
    setState(() {
      if (selected) {
        _selectedExtras.add(extra);
      } else {
        _selectedExtras.remove(extra);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final food = widget.food;
    final theme = Theme.of(context);
    final muted = AppColors.mutedOf(context);
    final restaurant = RestaurantService.findRestaurant(food.restaurantId);
    final category = MockData.categoryById(food.categoryId);
    final isOpen = restaurant?.isOpen ?? true;

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            backgroundColor: MockData.gradientForCategory(food.categoryId).first,
            foregroundColor: Colors.white,
            actions: [
              FavoriteButton(id: food.id, type: FavoriteType.food, size: 20),
              const CartIconButton(color: Colors.white),
              const SizedBox(width: 4),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: FoodVisual(
                emoji: food.emoji,
                colors: MockData.gradientForCategory(food.categoryId),
                emojiSize: 130,
                borderRadius: 0,
                heroTag: widget.heroTag,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 24),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(food.name, style: theme.textTheme.headlineMedium),
                      const SizedBox(height: 6),
                      if (restaurant != null)
                        InkWell(
                          borderRadius: BorderRadius.circular(8),
                          onTap: () => openRestaurant(context, restaurant),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Text(restaurant.logoEmoji),
                                const SizedBox(width: 6),
                                Flexible(
                                  child: Text(
                                    '${restaurant.name} • ${restaurant.location}',
                                    style: TextStyle(
                                      color: AppColors.accentOf(context),
                                      fontWeight: FontWeight.w700,
                                    ),
                                  ),
                                ),
                                Icon(Icons.chevron_right_rounded,
                                    color: AppColors.accentOf(context)),
                              ],
                            ),
                          ),
                        ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          PriceWidget(amount: food.price, fontSize: 24),
                          const Spacer(),
                          RatingWidget(rating: food.rating),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 6,
                        runSpacing: 6,
                        children: [
                          if (category != null)
                            FoodTag(
                              text: '${category.emoji} ${category.name}',
                              color: category.color.withAlpha(45),
                            ),
                          if (food.isEthiopian)
                            FoodTag(
                                text: '🇪🇹 Ethiopian',
                                color: AppColors.flagGreen.withAlpha(45)),
                          if (food.isSpicy)
                            FoodTag(
                                text: '🌶️ Spicy',
                                color: AppColors.berbere.withAlpha(40)),
                          if (food.isVegetarian)
                            FoodTag(
                                text: '🌱 Vegetarian',
                                color: AppColors.flagGreenLight.withAlpha(45)),
                          if (food.isPopular)
                            FoodTag(
                                text: '🔥 Popular',
                                color: AppColors.meskelGold.withAlpha(70)),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(food.description,
                          style: TextStyle(height: 1.5, color: muted, fontSize: 15)),
                      if (food.ingredients.isNotEmpty) ...[
                        const SizedBox(height: 20),
                        Text('Ingredients', style: theme.textTheme.titleMedium),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: food.ingredients
                              .map((i) => Chip(
                                    label: Text(i),
                                    visualDensity: VisualDensity.compact,
                                  ))
                              .toList(),
                        ),
                      ],
                      if (food.extras.isNotEmpty) ...[
                        const SizedBox(height: 20),
                        Text('Add extras', style: theme.textTheme.titleMedium),
                        const SizedBox(height: 4),
                        for (final extra in food.extras)
                          CheckboxListTile(
                            contentPadding: EdgeInsets.zero,
                            value: _selectedExtras.contains(extra),
                            onChanged: (value) =>
                                _toggleExtra(extra, value ?? false),
                            title: Text(extra.name),
                            secondary: Text(
                              '+${formatBirr(extra.price)}',
                              style: const TextStyle(fontWeight: FontWeight.w700),
                            ),
                          ),
                      ],
                      const SizedBox(height: 16),
                      Text('Note for the kitchen',
                          style: theme.textTheme.titleMedium),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _noteController,
                        maxLines: 2,
                        maxLength: 120,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: const InputDecoration(
                          hintText: 'e.g. less spicy, extra awaze on the side',
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
          decoration: BoxDecoration(
            color: theme.colorScheme.surface,
            border: Border(top: BorderSide(color: theme.dividerColor)),
          ),
          child: Row(
            children: [
              QuantitySelector(
                quantity: _quantity,
                canDecrement: _quantity > 1,
                onIncrement: () => setState(() => _quantity++),
                onDecrement: () => setState(() => _quantity--),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: CustomButton(
                  label: isOpen ? 'Add  •  ${formatBirr(_total)}' : 'Closed now',
                  icon: isOpen ? Icons.add_shopping_cart_rounded : Icons.lock_clock_rounded,
                  onPressed: isOpen
                      ? () => CartActions.addToCart(
                            context,
                            food,
                            quantity: _quantity,
                            extras: List.of(_selectedExtras),
                            note: _noteController.text,
                          )
                      : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
