import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../models/restaurant.dart';
import '../models/review.dart';
import '../services/restaurant_service.dart';
import '../utils/formatters.dart';
import '../widgets/cart_icon_button.dart';
import '../widgets/cart_summary_bar.dart';
import '../widgets/favorite_button.dart';
import '../widgets/food_card.dart';
import '../widgets/food_visual.dart';
import '../widgets/rating_widget.dart';
import '../widgets/section_header.dart';
import '../widgets/tibeb_stripe.dart';

class RestaurantDetailsScreen extends StatefulWidget {
  final Restaurant restaurant;
  final String? heroTag;

  const RestaurantDetailsScreen({
    super.key,
    required this.restaurant,
    this.heroTag,
  });

  @override
  State<RestaurantDetailsScreen> createState() =>
      _RestaurantDetailsScreenState();
}

class _RestaurantDetailsScreenState extends State<RestaurantDetailsScreen> {
  String? _selectedCategoryId;

  @override
  Widget build(BuildContext context) {
    final restaurant = widget.restaurant;
    final theme = Theme.of(context);
    final menu = RestaurantService.menuFor(restaurant.id);
    final categories = RestaurantService.categoriesFor(restaurant.id);
    final visibleMenu = _selectedCategoryId == null
        ? menu
        : menu.where((f) => f.categoryId == _selectedCategoryId).toList();
    final reviews = RestaurantService.reviewsFor(restaurant.id);

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 240,
            pinned: true,
            stretch: true,
            backgroundColor: restaurant.gradient.first,
            foregroundColor: Colors.white,
            title: Text(restaurant.name,
                style: const TextStyle(color: Colors.white)),
            actions: [
              FavoriteButton(
                  id: restaurant.id, type: FavoriteType.restaurant, size: 20),
              const CartIconButton(color: Colors.white),
              const SizedBox(width: 4),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: FoodVisual(
                emoji: restaurant.coverEmoji,
                colors: restaurant.gradient,
                emojiSize: 100,
                borderRadius: 0,
                heroTag: widget.heroTag,
              ),
            ),
          ),
          const SliverToBoxAdapter(child: TibebStripe(height: 12)),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(restaurant.logoEmoji,
                          style: const TextStyle(fontSize: 34)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(restaurant.name,
                            style: theme.textTheme.headlineSmall),
                      ),
                      _OpenBadge(isOpen: restaurant.isOpen),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    restaurant.description,
                    style: TextStyle(
                        color: AppColors.mutedOf(context), height: 1.4),
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      for (final tag in [restaurant.cuisine.label, ...restaurant.tags])
                        Chip(
                          label: Text(tag),
                          visualDensity: VisualDensity.compact,
                        ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surface,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: _Stat(
                            top: RatingWidget(rating: restaurant.rating),
                            label: '${restaurant.reviewCount} reviews',
                          ),
                        ),
                        Expanded(
                          child: _Stat(
                            top: Text(restaurant.deliveryTimeLabel,
                                style: const TextStyle(fontWeight: FontWeight.w800)),
                            label: 'Delivery',
                          ),
                        ),
                        Expanded(
                          child: _Stat(
                            top: Text(
                              restaurant.hasFreeDelivery
                                  ? 'Free'
                                  : formatBirr(restaurant.deliveryFee),
                              style: const TextStyle(fontWeight: FontWeight.w800),
                            ),
                            label: 'Fee',
                          ),
                        ),
                        Expanded(
                          child: _Stat(
                            top: Text(restaurant.location,
                                style: const TextStyle(fontWeight: FontWeight.w800)),
                            label: 'Area',
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.schedule_rounded,
                          size: 16, color: AppColors.mutedOf(context)),
                      const SizedBox(width: 6),
                      Text('Open ${restaurant.openingHours}',
                          style: TextStyle(color: AppColors.mutedOf(context))),
                    ],
                  ),
                  if (!restaurant.isOpen) ...[
                    const SizedBox(height: 12),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: AppColors.meskelGold.withAlpha(40),
                        borderRadius: BorderRadius.circular(16),
                      ),
                      child: const Row(
                        children: [
                          Text('🌙', style: TextStyle(fontSize: 22)),
                          SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              'This restaurant is closed right now. You can browse the menu, but ordering is paused until it opens.',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SectionHeader(
                title: 'Menu', subtitle: '${menu.length} dishes'),
          ),
          SliverToBoxAdapter(
            child: SizedBox(
              height: 44,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: const Text('All'),
                      selected: _selectedCategoryId == null,
                      onSelected: (_) =>
                          setState(() => _selectedCategoryId = null),
                    ),
                  ),
                  for (final category in categories)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ChoiceChip(
                        label: Text('${category.emoji} ${category.name}'),
                        selected: _selectedCategoryId == category.id,
                        onSelected: (_) =>
                            setState(() => _selectedCategoryId = category.id),
                      ),
                    ),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            sliver: SliverList.separated(
              itemCount: visibleMenu.length,
              separatorBuilder: (context, index) => const SizedBox(height: 10),
              itemBuilder: (context, index) => FoodListTile(
                food: visibleMenu[index],
                heroPrefix: 'menu-${restaurant.id}',
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: SectionHeader(
              title: 'Reviews',
              subtitle: '${restaurant.rating} average from ${restaurant.reviewCount} people',
            ),
          ),
          if (reviews.isEmpty)
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text('No written reviews yet.'),
              ),
            )
          else
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverList.separated(
                itemCount: reviews.length,
                separatorBuilder: (context, index) => const SizedBox(height: 10),
                itemBuilder: (context, index) => _ReviewTile(review: reviews[index]),
              ),
            ),
          const SliverToBoxAdapter(child: SizedBox(height: 32)),
        ],
      ),
      bottomNavigationBar: const CartSummaryBar(),
    );
  }
}

class _OpenBadge extends StatelessWidget {
  final bool isOpen;

  const _OpenBadge({required this.isOpen});

  @override
  Widget build(BuildContext context) {
    final color = isOpen ? AppColors.flagGreen : AppColors.error;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        isOpen ? 'Open' : 'Closed',
        style: TextStyle(color: color, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final Widget top;
  final String label;

  const _Stat({required this.top, required this.label});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        FittedBox(fit: BoxFit.scaleDown, child: top),
        const SizedBox(height: 4),
        Text(label,
            style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context))),
      ],
    );
  }
}

class _ReviewTile extends StatelessWidget {
  final Review review;

  const _ReviewTile({required this.review});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 16,
                backgroundColor: AppColors.meskelGold,
                child: Text(
                  review.userName[0],
                  style: const TextStyle(
                      color: AppColors.charcoal, fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(review.userName,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
              RatingWidget(rating: review.rating, compact: true),
            ],
          ),
          const SizedBox(height: 8),
          Text(review.comment, style: const TextStyle(height: 1.4)),
          const SizedBox(height: 4),
          Text(formatDate(review.date),
              style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context))),
        ],
      ),
    );
  }
}
