import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../data/mock_data.dart';
import '../models/food_item.dart';
import '../models/restaurant.dart';
import '../services/restaurant_service.dart';
import '../services/search_history_service.dart';
import '../utils/formatters.dart';
import '../widgets/app_search_bar.dart';
import '../widgets/cart_icon_button.dart';
import '../widgets/custom_button.dart';
import '../widgets/empty_state.dart';
import '../widgets/food_card.dart';
import '../widgets/restaurant_card.dart';

/// Search, filter and sort restaurants and dishes.
class ExploreScreen extends StatefulWidget {
  final String? initialCategoryId;

  /// True when opened from a category (pushed as its own page).
  final bool standalone;

  const ExploreScreen({
    super.key,
    this.initialCategoryId,
    this.standalone = false,
  });

  @override
  State<ExploreScreen> createState() => ExploreScreenState();
}

class ExploreScreenState extends State<ExploreScreen> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  String _query = '';
  bool _showDishes = false;
  late RestaurantFilter _filter;
  List<String> _history = [];

  @override
  void initState() {
    super.initState();
    _filter = RestaurantFilter(categoryId: widget.initialCategoryId);
    _showDishes = widget.initialCategoryId != null;
    _history = SearchHistoryService.load();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  /// Called by MainShell when the Home search bar is tapped.
  void focusSearch() => _focusNode.requestFocus();

  void _saveSearch(String value) {
    final term = value.trim();
    if (term.isEmpty) return;
    setState(() {
      _history.remove(term);
      _history.insert(0, term);
      if (_history.length > SearchHistoryService.maxEntries) {
        _history = _history.sublist(0, SearchHistoryService.maxEntries);
      }
    });
    SearchHistoryService.save(_history);
  }

  void _useHistory(String term) {
    _searchController.text = term;
    setState(() => _query = term);
  }

  void _clearHistory() {
    setState(() => _history = []);
    SearchHistoryService.clear();
  }

  Future<void> _openFilters() async {
    final result = await showModalBottomSheet<RestaurantFilter>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => _FilterSheet(initial: _filter),
    );
    if (result != null) setState(() => _filter = result);
  }

  @override
  Widget build(BuildContext context) {
    final restaurants = RestaurantService.searchRestaurants(_query, _filter);
    final foods = RestaurantService.searchFoods(_query, _filter);
    final categoryName = widget.initialCategoryId == null
        ? null
        : MockData.categoryById(widget.initialCategoryId!)?.name;

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: widget.standalone,
        title: Text(widget.standalone ? (categoryName ?? 'Explore') : 'Explore'),
        actions: const [CartIconButton(), SizedBox(width: 4)],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: AppSearchBar(
              controller: _searchController,
              focusNode: _focusNode,
              onChanged: (value) => setState(() => _query = value),
              onSubmitted: _saveSearch,
            ),
          ),
          if (_query.isEmpty && _history.isNotEmpty) _buildHistory(),
          _buildToolbar(restaurants.length, foods.length),
          if (_filter.activeCount > 0) _buildActiveFilters(),
          Expanded(
            child: _showDishes
                ? _buildDishResults(foods)
                : _buildRestaurantResults(restaurants),
          ),
        ],
      ),
    );
  }

  Widget _buildHistory() {
    return SizedBox(
      height: 44,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        children: [
          Center(
            child: Icon(Icons.history_rounded,
                size: 18, color: AppColors.mutedOf(context)),
          ),
          const SizedBox(width: 6),
          for (final term in _history)
            Padding(
              padding: const EdgeInsets.only(right: 6),
              child: ActionChip(
                label: Text(term),
                onPressed: () => _useHistory(term),
              ),
            ),
          TextButton(onPressed: _clearHistory, child: const Text('Clear')),
        ],
      ),
    );
  }

  Widget _buildToolbar(int restaurantCount, int dishCount) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 8, 4),
      child: Row(
        children: [
          Expanded(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  ChoiceChip(
                    label: Text('Restaurants ($restaurantCount)'),
                    selected: !_showDishes,
                    onSelected: (_) => setState(() => _showDishes = false),
                  ),
                  const SizedBox(width: 8),
                  ChoiceChip(
                    label: Text('Dishes ($dishCount)'),
                    selected: _showDishes,
                    onSelected: (_) => setState(() => _showDishes = true),
                  ),
                ],
              ),
            ),
          ),
          IconButton(
            tooltip: 'Filters',
            onPressed: _openFilters,
            icon: Badge(
              isLabelVisible: _filter.activeCount > 0,
              label: Text('${_filter.activeCount}'),
              child: const Icon(Icons.tune_rounded),
            ),
          ),
          PopupMenuButton<SortOption>(
            tooltip: 'Sort',
            icon: const Icon(Icons.sort_rounded),
            initialValue: _filter.sort,
            onSelected: (sort) =>
                setState(() => _filter = _filter.copyWith(sort: sort)),
            itemBuilder: (context) => SortOption.values
                .map((option) => PopupMenuItem<SortOption>(
                      value: option,
                      child: Row(
                        children: [
                          Icon(
                            option == _filter.sort
                                ? Icons.radio_button_checked_rounded
                                : Icons.radio_button_off_rounded,
                            size: 18,
                          ),
                          const SizedBox(width: 10),
                          Text(option.label),
                        ],
                      ),
                    ))
                .toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildActiveFilters() {
    final chips = <Widget>[];
    final categoryId = _filter.categoryId;
    if (categoryId != null) {
      chips.add(InputChip(
        label: Text(MockData.categoryById(categoryId)?.name ?? categoryId),
        onDeleted: () => setState(
            () => _filter = _filter.copyWith(clearCategory: true)),
      ));
    }
    final maxPrice = _filter.maxPrice;
    if (maxPrice != null) {
      chips.add(InputChip(
        label: Text('Under ${formatBirr(maxPrice)}'),
        onDeleted: () =>
            setState(() => _filter = _filter.copyWith(clearPrice: true)),
      ));
    }
    if (_filter.minRating > 0) {
      chips.add(InputChip(
        label: Text('${_filter.minRating}+ stars'),
        onDeleted: () =>
            setState(() => _filter = _filter.copyWith(minRating: 0)),
      ));
    }
    final maxMinutes = _filter.maxDeliveryMinutes;
    if (maxMinutes != null) {
      chips.add(InputChip(
        label: Text('≤ $maxMinutes min'),
        onDeleted: () =>
            setState(() => _filter = _filter.copyWith(clearDelivery: true)),
      ));
    }
    final location = _filter.location;
    if (location != null) {
      chips.add(InputChip(
        label: Text(location),
        onDeleted: () =>
            setState(() => _filter = _filter.copyWith(clearLocation: true)),
      ));
    }

    return SizedBox(
      height: 48,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: chips.length,
        separatorBuilder: (context, index) => const SizedBox(width: 6),
        itemBuilder: (context, index) => Center(child: chips[index]),
      ),
    );
  }

  Widget _noResults() {
    return EmptyState(
      emoji: '🔍',
      title: 'No matches found',
      message: _query.isEmpty
          ? 'No results with these filters. Try removing one.'
          : 'Nothing matches "$_query". Try "tibs", "pizza" or an area like "Bole".',
      actionLabel: 'Reset search',
      onAction: () {
        _searchController.clear();
        setState(() {
          _query = '';
          _filter = RestaurantFilter(sort: _filter.sort);
        });
      },
    );
  }

  Widget _buildRestaurantResults(List<Restaurant> restaurants) {
    if (restaurants.isEmpty) return _noResults();
    return LayoutBuilder(
      builder: (context, constraints) {
        // Responsive: 1 column on phones, 2–3 on tablets.
        final columns = (constraints.maxWidth / 420).floor().clamp(1, 3).toInt();
        return GridView.builder(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          itemCount: restaurants.length,
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            mainAxisExtent: 214,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
          ),
          itemBuilder: (context, index) => RestaurantCard(
            restaurant: restaurants[index],
            heroPrefix: 'explore',
          ),
        );
      },
    );
  }

  Widget _buildDishResults(List<FoodItem> foods) {
    if (foods.isEmpty) return _noResults();
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
      itemCount: foods.length,
      separatorBuilder: (context, index) => const SizedBox(height: 10),
      itemBuilder: (context, index) => FoodListTile(
        food: foods[index],
        heroPrefix: 'explore',
        showRestaurant: true,
      ),
    );
  }
}

/// Bottom sheet with every filter. Returns the new filter when applied.
class _FilterSheet extends StatefulWidget {
  final RestaurantFilter initial;

  const _FilterSheet({required this.initial});

  @override
  State<_FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<_FilterSheet> {
  static const double _priceMax = 1200;

  late String? _categoryId = widget.initial.categoryId;
  late double _maxPrice = widget.initial.maxPrice ?? _priceMax;
  late double _minRating = widget.initial.minRating;
  late int? _maxMinutes = widget.initial.maxDeliveryMinutes;
  late String? _location = widget.initial.location;

  void _reset() {
    setState(() {
      _categoryId = null;
      _maxPrice = _priceMax;
      _minRating = 0;
      _maxMinutes = null;
      _location = null;
    });
  }

  void _apply() {
    Navigator.pop(
      context,
      RestaurantFilter(
        categoryId: _categoryId,
        maxPrice: _maxPrice >= _priceMax ? null : _maxPrice,
        minRating: _minRating,
        maxDeliveryMinutes: _maxMinutes,
        location: _location,
        sort: widget.initial.sort,
      ),
    );
  }

  Widget _label(String text) => Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 8),
        child: Text(text, style: Theme.of(context).textTheme.titleSmall),
      );

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxHeight: MediaQuery.of(context).size.height * 0.85,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Filters', style: Theme.of(context).textTheme.titleLarge),
                    _label('Category'),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        ChoiceChip(
                          label: const Text('All'),
                          selected: _categoryId == null,
                          onSelected: (_) => setState(() => _categoryId = null),
                        ),
                        for (final category in MockData.categories)
                          ChoiceChip(
                            label: Text('${category.emoji} ${category.name}'),
                            selected: _categoryId == category.id,
                            onSelected: (_) =>
                                setState(() => _categoryId = category.id),
                          ),
                      ],
                    ),
                    _label(_maxPrice >= _priceMax
                        ? 'Price: any'
                        : 'Price: up to ${formatBirr(_maxPrice)}'),
                    Slider(
                      value: _maxPrice,
                      min: 100,
                      max: _priceMax,
                      divisions: 11,
                      label: formatBirr(_maxPrice),
                      onChanged: (value) => setState(() => _maxPrice = value),
                    ),
                    _label('Minimum rating'),
                    Wrap(
                      spacing: 8,
                      children: [
                        for (final rating in [0.0, 4.0, 4.5, 4.7])
                          ChoiceChip(
                            label: Text(rating == 0 ? 'Any' : '$rating ★'),
                            selected: _minRating == rating,
                            onSelected: (_) => setState(() => _minRating = rating),
                          ),
                      ],
                    ),
                    _label('Delivery time'),
                    Wrap(
                      spacing: 8,
                      children: [
                        for (final minutes in <int?>[null, 25, 30, 40])
                          ChoiceChip(
                            label: Text(minutes == null ? 'Any' : '≤ $minutes min'),
                            selected: _maxMinutes == minutes,
                            onSelected: (_) => setState(() => _maxMinutes = minutes),
                          ),
                      ],
                    ),
                    _label('Location'),
                    InputDecorator(
                      decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.location_on_outlined),
                        contentPadding:
                            EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      ),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String?>(
                          value: _location,
                          isExpanded: true,
                          hint: const Text('All of Addis Ababa'),
                          items: [
                            const DropdownMenuItem<String?>(
                              value: null,
                              child: Text('All of Addis Ababa'),
                            ),
                            for (final area in AppConstants.addisAreas)
                              DropdownMenuItem<String?>(
                                value: area,
                                child: Text(area),
                              ),
                          ],
                          onChanged: (value) => setState(() => _location = value),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
              child: Row(
                children: [
                  Expanded(
                    child: CustomButton(
                      label: 'Reset',
                      variant: ButtonVariant.outline,
                      onPressed: _reset,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: CustomButton(label: 'Show results', onPressed: _apply),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
