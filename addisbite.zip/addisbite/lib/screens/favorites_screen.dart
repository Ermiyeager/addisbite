import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/favorites_provider.dart';
import '../widgets/empty_state.dart';
import '../widgets/food_card.dart';
import '../widgets/restaurant_card.dart';
import 'main_shell.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final favorites = context.watch<FavoritesProvider>();
    final restaurants = favorites.favoriteRestaurants;
    final foods = favorites.favoriteFoods;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Favorites'),
          bottom: TabBar(
            tabs: [
              Tab(text: 'Restaurants (${restaurants.length})'),
              Tab(text: 'Dishes (${foods.length})'),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            restaurants.isEmpty
                ? EmptyState(
                    emoji: '💛',
                    title: 'No favourite restaurants',
                    message: 'Tap the heart on any restaurant to save it here.',
                    actionLabel: 'Explore restaurants',
                    onAction: () => MainShell.goToTab(1),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: restaurants.length,
                    separatorBuilder: (context, index) => const SizedBox(height: 12),
                    itemBuilder: (context, index) => RestaurantCard(
                      restaurant: restaurants[index],
                      heroPrefix: 'fav',
                    ),
                  ),
            foods.isEmpty
                ? EmptyState(
                    emoji: '🍽️',
                    title: 'No favourite dishes',
                    message: 'Save the dishes you love so you can order them again quickly.',
                    actionLabel: 'Explore dishes',
                    onAction: () => MainShell.goToTab(1),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: foods.length,
                    separatorBuilder: (context, index) => const SizedBox(height: 10),
                    itemBuilder: (context, index) => FoodListTile(
                      food: foods[index],
                      heroPrefix: 'fav',
                      showRestaurant: true,
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}
