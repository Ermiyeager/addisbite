import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../models/address.dart';
import '../models/order.dart';
import '../providers/auth_provider.dart';
import '../providers/cart_provider.dart';
import '../providers/order_provider.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';
import '../utils/validators.dart';
import '../widgets/custom_button.dart';
import 'order_confirmation_screen.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _phoneController;
  late final TextEditingController _streetController;
  final _instructionsController = TextEditingController();
  final _cardController = TextEditingController();

  late String _area;
  PaymentMethod _payment = PaymentMethod.cash;
  bool _scheduleLater = false;
  DateTime? _scheduledFor;
  bool _saveAddress = true;
  bool _isPlacing = false;

  @override
  void initState() {
    super.initState();
    // Pre-fill the form from the logged-in user's profile.
    final user = context.read<AuthProvider>().user;
    _nameController = TextEditingController(text: user?.name ?? '');
    _phoneController = TextEditingController(text: user?.phone ?? '');
    _streetController = TextEditingController(text: user?.street ?? '');
    final area = user?.area;
    _area = area != null && AppConstants.addisAreas.contains(area)
        ? area
        : AppConstants.addisAreas.first;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _phoneController.dispose();
    _streetController.dispose();
    _instructionsController.dispose();
    _cardController.dispose();
    super.dispose();
  }

  Future<void> _pickSchedule() async {
    final now = DateTime.now();
    final date = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: now,
      lastDate: now.add(const Duration(days: 7)),
      helpText: 'Delivery date',
    );
    if (date == null || !mounted) return;

    final time = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(now.add(const Duration(hours: 1))),
      helpText: 'Delivery time',
    );
    if (time == null || !mounted) return;

    final chosen =
        DateTime(date.year, date.month, date.day, time.hour, time.minute);
    if (chosen.isBefore(now.add(const Duration(minutes: 30)))) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Choose a time at least 30 minutes from now.'),
      ));
      return;
    }
    setState(() => _scheduledFor = chosen);
  }

  Future<void> _placeOrder() async {
    FocusScope.of(context).unfocus();
    final messenger = ScaffoldMessenger.of(context);

    if (!(_formKey.currentState?.validate() ?? false)) {
      messenger.showSnackBar(const SnackBar(
          content: Text('Please fix the highlighted fields.')));
      return;
    }
    if (_scheduleLater && _scheduledFor == null) {
      messenger.showSnackBar(const SnackBar(
          content: Text('Pick a delivery date and time, or turn off scheduling.')));
      return;
    }

    final cart = context.read<CartProvider>();
    final orders = context.read<OrderProvider>();
    final auth = context.read<AuthProvider>();
    final navigator = Navigator.of(context);

    final address = Address(
      fullName: _nameController.text.trim(),
      phone: _phoneController.text.trim(),
      area: _area,
      street: _streetController.text.trim(),
      instructions: _instructionsController.text.trim(),
    );

    setState(() => _isPlacing = true);
    try {
      final order = await orders.placeOrder(
        items: cart.items,
        address: address,
        paymentMethod: _payment,
        subtotal: cart.subtotal,
        deliveryFee: cart.deliveryFee,
        discount: cart.discount,
        total: cart.total,
        promoCode: cart.appliedPromo?.code,
        scheduledFor: _scheduleLater ? _scheduledFor : null,
      );

      final user = auth.user;
      if (_saveAddress && user != null) {
        await auth.updateProfile(user.copyWith(
          phone: address.phone,
          area: address.area,
          street: address.street,
        ));
      }

      cart.clear();
      // Remove cart + checkout from the stack, keep the main shell.
      navigator.pushAndRemoveUntil(
        buildRoute(OrderConfirmationScreen(orderId: order.id)),
        (route) => route.isFirst,
      );
    } on OrderException catch (e) {
      messenger.showSnackBar(SnackBar(
        content: Text(e.message),
        backgroundColor: AppColors.error,
      ));
    } catch (e) {
      messenger.showSnackBar(const SnackBar(
        content: Text('Could not place your order. Check your connection and try again.'),
        backgroundColor: AppColors.error,
      ));
    } finally {
      if (mounted) setState(() => _isPlacing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final theme = Theme.of(context);
    final scheduled = _scheduledFor;

    return Scaffold(
      appBar: AppBar(title: const Text('Checkout')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
              children: [
                const _StepTitle(icon: Icons.location_on_rounded, title: 'Delivery address'),
                TextFormField(
                  controller: _nameController,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    labelText: 'Full name',
                    prefixIcon: Icon(Icons.person_outline_rounded),
                  ),
                  validator: Validators.name,
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                    labelText: 'Phone number',
                    hintText: '0911 234 567',
                    prefixIcon: Icon(Icons.phone_outlined),
                  ),
                  validator: Validators.phone,
                ),
                const SizedBox(height: 12),
                InputDecorator(
                  decoration: const InputDecoration(
                    labelText: 'Area',
                    prefixIcon: Icon(Icons.map_outlined),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      value: _area,
                      isExpanded: true,
                      isDense: true,
                      items: AppConstants.addisAreas
                          .map((area) => DropdownMenuItem<String>(
                              value: area, child: Text(area)))
                          .toList(),
                      onChanged: (value) {
                        if (value != null) setState(() => _area = value);
                      },
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _streetController,
                  decoration: const InputDecoration(
                    labelText: 'Street, building or house number',
                    prefixIcon: Icon(Icons.home_outlined),
                  ),
                  validator: (value) =>
                      Validators.requiredField(value, 'Street or house number'),
                ),
                const SizedBox(height: 12),
                TextFormField(
                  controller: _instructionsController,
                  maxLines: 2,
                  decoration: const InputDecoration(
                    labelText: 'Instructions for the rider (optional)',
                    hintText: 'e.g. Near Edna Mall, blue gate',
                    prefixIcon: Icon(Icons.notes_rounded),
                  ),
                ),
                CheckboxListTile(
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                  value: _saveAddress,
                  onChanged: (value) => setState(() => _saveAddress = value ?? true),
                  title: const Text('Save this address to my profile'),
                ),
                const _StepTitle(icon: Icons.schedule_rounded, title: 'Delivery time'),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: _scheduleLater,
                  onChanged: (value) => setState(() => _scheduleLater = value),
                  title: const Text('Schedule for later'),
                  subtitle: Text(_scheduleLater
                      ? (scheduled == null
                          ? 'Choose a date and time'
                          : formatDateTime(scheduled))
                      : 'As soon as possible (${cart.restaurant?.deliveryTimeLabel ?? '30–40 min'})'),
                ),
                if (_scheduleLater)
                  CustomButton(
                    label: scheduled == null ? 'Pick date and time' : 'Change date and time',
                    icon: Icons.calendar_month_rounded,
                    variant: ButtonVariant.outline,
                    onPressed: _pickSchedule,
                  ),
                const _StepTitle(icon: Icons.payments_rounded, title: 'Payment method'),
                for (final method in PaymentMethod.values)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _PaymentTile(
                      method: method,
                      selected: _payment == method,
                      onTap: () => setState(() => _payment = method),
                    ),
                  ),
                AnimatedSize(
                  duration: const Duration(milliseconds: 250),
                  child: switch (_payment) {
                    PaymentMethod.card => TextFormField(
                        controller: _cardController,
                        keyboardType: TextInputType.number,
                        maxLength: 19,
                        decoration: const InputDecoration(
                          labelText: 'Card number',
                          hintText: '1234 5678 9012 3456',
                          prefixIcon: Icon(Icons.credit_card_rounded),
                          helperText: 'Demo only: no real payment is made.',
                        ),
                        validator: Validators.cardNumber,
                      ),
                    PaymentMethod.telebirr => _InfoNote(
                        text:
                            'A Telebirr payment request will be sent to ${_phoneController.text.isEmpty ? 'your phone' : _phoneController.text} (simulated).',
                      ),
                    PaymentMethod.cash => const _InfoNote(
                        text: 'Please have the exact amount ready for the rider.',
                      ),
                  },
                ),
                const _StepTitle(icon: Icons.receipt_long_rounded, title: 'Order summary'),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      for (final item in cart.items)
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 4),
                          child: Row(
                            children: [
                              Text('${item.quantity}×',
                                  style: const TextStyle(fontWeight: FontWeight.w800)),
                              const SizedBox(width: 8),
                              Expanded(child: Text(item.food.name)),
                              Text(formatBirr(item.totalPrice)),
                            ],
                          ),
                        ),
                      const Divider(height: 20),
                      _SummaryRow(label: 'Subtotal', value: formatBirr(cart.subtotal)),
                      _SummaryRow(
                        label: 'Delivery',
                        value: cart.deliveryFee == 0 ? 'Free' : formatBirr(cart.deliveryFee),
                      ),
                      if (cart.discount > 0)
                        _SummaryRow(
                          label: 'Discount (${cart.appliedPromo?.code})',
                          value: '-${formatBirr(cart.discount)}',
                        ),
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Expanded(
                            child: Text('Total', style: theme.textTheme.titleLarge),
                          ),
                          Text(
                            formatBirr(cart.total),
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.w900,
                              color: AppColors.accentOf(context),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: CustomButton(
            label: 'Place order  •  ${formatBirr(cart.total)}',
            icon: Icons.check_rounded,
            isLoading: _isPlacing,
            onPressed: cart.isEmpty ? null : _placeOrder,
          ),
        ),
      ),
    );
  }
}

class _StepTitle extends StatelessWidget {
  final IconData icon;
  final String title;

  const _StepTitle({required this.icon, required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 12),
      child: Row(
        children: [
          Icon(icon, color: AppColors.accentOf(context)),
          const SizedBox(width: 8),
          Text(title, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}

class _PaymentTile extends StatelessWidget {
  final PaymentMethod method;
  final bool selected;
  final VoidCallback onTap;

  const _PaymentTile({
    required this.method,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Semantics(
      selected: selected,
      button: true,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: selected
                ? primary.withAlpha(22)
                : Theme.of(context).colorScheme.surface,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: selected ? primary : Colors.transparent,
              width: 2,
            ),
          ),
          child: Row(
            children: [
              Text(method.emoji, style: const TextStyle(fontSize: 26)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(method.label,
                        style: const TextStyle(fontWeight: FontWeight.w800)),
                    Text(method.subtitle,
                        style: TextStyle(
                            fontSize: 12, color: AppColors.mutedOf(context))),
                  ],
                ),
              ),
              Icon(
                selected
                    ? Icons.radio_button_checked_rounded
                    : Icons.radio_button_off_rounded,
                color: selected ? primary : AppColors.mutedOf(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InfoNote extends StatelessWidget {
  final String text;

  const _InfoNote({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.meskelGold.withAlpha(35),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Row(
        children: [
          const Icon(Icons.info_outline_rounded, size: 20),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label;
  final String value;

  const _SummaryRow({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(
            child: Text(label,
                style: TextStyle(color: AppColors.mutedOf(context))),
          ),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
