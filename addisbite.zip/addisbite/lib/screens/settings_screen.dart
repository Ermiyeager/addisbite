import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../providers/settings_provider.dart';
import '../services/search_history_service.dart';
import '../utils/navigation.dart';
import 'edit_profile_screen.dart';
import 'profile_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Widget _sectionTitle(BuildContext context, String title) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 20, 4, 8),
        child: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: AppColors.accentOf(context),
          ),
        ),
      );

  Widget _group(BuildContext context, List<Widget> children) => Material(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        clipBehavior: Clip.antiAlias,
        child: Column(children: children),
      );

  @override
  Widget build(BuildContext context) {
    final settings = context.watch<SettingsProvider>();

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
            children: [
              _sectionTitle(context, 'Appearance'),
              _group(context, [
                SwitchListTile(
                  secondary: const Icon(Icons.dark_mode_outlined),
                  title: const Text('Dark mode'),
                  subtitle: const Text('Easier on the eyes at night'),
                  value: settings.isDarkMode,
                  onChanged: settings.setDarkMode,
                ),
              ]),
              _sectionTitle(context, 'Preferences'),
              _group(context, [
                SwitchListTile(
                  secondary: const Icon(Icons.notifications_outlined),
                  title: const Text('Order notifications'),
                  subtitle: const Text('Status updates and offers'),
                  value: settings.notificationsEnabled,
                  onChanged: settings.setNotifications,
                ),
                ListTile(
                  leading: const Icon(Icons.language_rounded),
                  title: const Text('Language'),
                  trailing: DropdownButton<String>(
                    value: settings.language,
                    underline: const SizedBox.shrink(),
                    items: AppConstants.languages
                        .map((language) => DropdownMenuItem<String>(
                            value: language, child: Text(language)))
                        .toList(),
                    onChanged: (value) {
                      if (value == null) return;
                      settings.setLanguage(value);
                      if (value != AppConstants.languages.first) {
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                          content: Text(
                              '$value saved. Full translation is coming in the next version.'),
                        ));
                      }
                    },
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.history_rounded),
                  title: const Text('Clear search history'),
                  onTap: () async {
                    final messenger = ScaffoldMessenger.of(context);
                    await SearchHistoryService.clear();
                    messenger.showSnackBar(const SnackBar(
                      content: Text('Search history cleared. It will disappear the next time you open the app.'),
                    ));
                  },
                ),
              ]),
              _sectionTitle(context, 'Account'),
              _group(context, [
                ListTile(
                  leading: const Icon(Icons.manage_accounts_outlined),
                  title: const Text('Account settings'),
                  subtitle: const Text('Name and phone number'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => pushScreen(context, const EditProfileScreen()),
                ),
                ListTile(
                  leading: const Icon(Icons.location_on_outlined),
                  title: const Text('Address settings'),
                  subtitle: const Text('Area and street for delivery'),
                  trailing: const Icon(Icons.chevron_right_rounded),
                  onTap: () => pushScreen(context, const EditProfileScreen()),
                ),
              ]),
              _sectionTitle(context, 'About'),
              _group(context, [
                ListTile(
                  leading: const Icon(Icons.info_outline_rounded),
                  title: const Text('About AddisBite'),
                  subtitle: const Text('Version ${AppConstants.version}'),
                  onTap: () => showAboutDialog(
                    context: context,
                    applicationName: AppConstants.appName,
                    applicationVersion: AppConstants.version,
                    applicationIcon:
                        const Text('🍲', style: TextStyle(fontSize: 40)),
                    applicationLegalese: '© 2026 AddisBite • University project',
                    children: const [
                      SizedBox(height: 12),
                      Text(
                        '${AppConstants.tagline}\n\n'
                        'A food delivery demo for Addis Ababa built with Flutter, '
                        'Provider and SharedPreferences.',
                      ),
                    ],
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.logout_rounded, color: AppColors.error),
                  title: const Text('Log out',
                      style: TextStyle(
                          color: AppColors.error, fontWeight: FontWeight.w600)),
                  onTap: () => confirmLogout(context),
                ),
              ]),
            ],
          ),
        ),
      ),
    );
  }
}
