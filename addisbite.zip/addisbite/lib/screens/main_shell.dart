import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/order_provider.dart';
import 'explore_screen.dart';
import 'favorites_screen.dart';
import 'home_screen.dart';
import 'orders_screen.dart';
import 'profile_screen.dart';

/// The main screen with the bottom navigation bar.
/// IndexedStack keeps every tab alive, so scroll positions and search
/// text are not lost when switching tabs.
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  /// Lets any screen switch tabs, e.g. "Browse food" on an empty page.
  /// Always create the shell as MainShell(key: MainShell.shellKey).
  static final GlobalKey<MainShellState> shellKey = GlobalKey<MainShellState>();

  static void goToTab(int index) => shellKey.currentState?.setTab(index);

  @override
  State<MainShell> createState() => MainShellState();
}

class MainShellState extends State<MainShell> {
  int _index = 0;
  final GlobalKey<ExploreScreenState> _exploreKey =
      GlobalKey<ExploreScreenState>();

  void setTab(int index) {
    if (index == _index) return;
    setState(() => _index = index);
  }

  /// Opens the Explore tab and puts the cursor in its search field.
  void openExploreSearch() {
    setTab(1);
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => _exploreKey.currentState?.focusSearch(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final activeOrders = context.watch<OrderProvider>().activeOrders.length;

    return Scaffold(
      body: IndexedStack(
        index: _index,
        children: [
          const HomeScreen(),
          ExploreScreen(key: _exploreKey),
          const OrdersScreen(),
          const FavoritesScreen(),
          const ProfileScreen(),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: setTab,
        destinations: [
          const NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Home',
          ),
          const NavigationDestination(
            icon: Icon(Icons.search_rounded),
            selectedIcon: Icon(Icons.manage_search_rounded),
            label: 'Explore',
          ),
          NavigationDestination(
            icon: Badge(
              isLabelVisible: activeOrders > 0,
              label: Text('$activeOrders'),
              child: const Icon(Icons.receipt_long_outlined),
            ),
            selectedIcon: Badge(
              isLabelVisible: activeOrders > 0,
              label: Text('$activeOrders'),
              child: const Icon(Icons.receipt_long_rounded),
            ),
            label: 'Orders',
          ),
          const NavigationDestination(
            icon: Icon(Icons.favorite_border_rounded),
            selectedIcon: Icon(Icons.favorite_rounded),
            label: 'Favorites',
          ),
          const NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}
