import 'dart:async';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../models/order.dart';
import '../providers/order_provider.dart';
import '../utils/cart_actions.dart';
import '../utils/formatters.dart';
import '../widgets/custom_button.dart';
import '../widgets/empty_state.dart';
import '../widgets/order_card.dart';

/// Shows live (simulated) progress. A Timer moves the order to the next
/// status every few seconds while this screen is open.
class OrderTrackingScreen extends StatefulWidget {
  final String orderId;

  const OrderTrackingScreen({super.key, required this.orderId});

  @override
  State<OrderTrackingScreen> createState() => _OrderTrackingScreenState();
}

class _OrderTrackingScreenState extends State<OrderTrackingScreen> {
  static const Duration _stepDuration = Duration(seconds: 6);
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(_stepDuration, (_) {
      if (!mounted) return;
      final provider = context.read<OrderProvider>();
      final order = provider.findById(widget.orderId);
      // Scheduled orders stay "confirmed" until their time; others move on.
      if (order == null || !order.isActive || order.scheduledFor != null) {
        _timer?.cancel();
        return;
      }
      provider.advanceStatus(order.id);
    });
  }

  @override
  void dispose() {
    _timer?.cancel(); // Always cancel timers to avoid memory leaks.
    super.dispose();
  }

  Future<void> _confirmCancel(Order order) async {
    final provider = context.read<OrderProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Cancel this order?'),
        content: const Text(
            'You can cancel only before the restaurant starts cooking.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Keep order'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Cancel order'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await provider.cancelOrder(order.id);
    messenger.showSnackBar(const SnackBar(content: Text('Order cancelled')));
  }

  @override
  Widget build(BuildContext context) {
    final order = context.watch<OrderProvider>().findById(widget.orderId);
    if (order == null) {
      return Scaffold(
        appBar: AppBar(),
        body: const EmptyState(
          emoji: '🧐',
          title: 'Order not found',
          message: 'This order may have been removed.',
        ),
      );
    }

    final steps = OrderStatusDetails.trackingSteps;
    final currentIndex = steps.indexOf(order.status); // -1 when cancelled
    final isCancelled = order.status == OrderStatus.cancelled;
    final progress =
        isCancelled ? 0.0 : (currentIndex / (steps.length - 1)).clamp(0.0, 1.0).toDouble();
    final showDriver = !isCancelled && currentIndex >= 2;
    final scheduled = order.scheduledFor;

    return Scaffold(
      appBar: AppBar(title: Text('Order ${order.id}')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            children: [
              // Status header
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  gradient: isCancelled
                      ? const LinearGradient(colors: [Color(0xFF6B6B6B), Color(0xFF9A9A9A)])
                      : order.status == OrderStatus.delivered
                          ? AppColors.greenGradient
                          : AppColors.berbereGradient,
                  borderRadius: BorderRadius.circular(26),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        AnimatedSwitcher(
                          duration: const Duration(milliseconds: 400),
                          transitionBuilder: (child, animation) =>
                              ScaleTransition(scale: animation, child: child),
                          child: Icon(
                            order.status.icon,
                            key: ValueKey<OrderStatus>(order.status),
                            color: Colors.white,
                            size: 40,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                order.status.label,
                                style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              Text(
                                order.status.description,
                                style: TextStyle(color: Colors.white.withAlpha(230)),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: TweenAnimationBuilder<double>(
                        tween: Tween<double>(end: progress),
                        duration: const Duration(milliseconds: 800),
                        curve: Curves.easeOutCubic,
                        builder: (context, value, child) => LinearProgressIndicator(
                          value: value,
                          minHeight: 10,
                          color: AppColors.meskelGold,
                          backgroundColor: Colors.white.withAlpha(60),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      isCancelled
                          ? 'Cancelled'
                          : order.status == OrderStatus.delivered
                              ? 'Delivered to ${order.address.shortLabel}'
                              : scheduled != null
                                  ? 'Scheduled for ${formatDateTime(scheduled)}'
                                  : 'Estimated arrival: ${formatTime(order.createdAt.add(Duration(minutes: order.etaMinutes)))}',
                      style: const TextStyle(
                          color: Colors.white, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              // Timeline
              if (!isCancelled)
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.surface,
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(
                    children: [
                      for (var i = 0; i < steps.length; i++)
                        _TimelineStep(
                          status: steps[i],
                          isDone: i < currentIndex ||
                              order.status == OrderStatus.delivered,
                          isCurrent: i == currentIndex && order.isActive,
                          isLast: i == steps.length - 1,
                        ),
                    ],
                  ),
                ),
              // Driver
              AnimatedSize(
                duration: const Duration(milliseconds: 350),
                child: showDriver
                    ? Padding(
                        padding: const EdgeInsets.only(top: 16),
                        child: _DriverCard(delivered: order.status == OrderStatus.delivered),
                      )
                    : const SizedBox(width: double.infinity),
              ),
              const SizedBox(height: 16),
              // Details
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(22),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(order.restaurantName,
                              style: Theme.of(context).textTheme.titleMedium),
                        ),
                        OrderStatusChip(status: order.status),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text('Placed ${formatDateTime(order.createdAt)}',
                        style: TextStyle(color: AppColors.mutedOf(context), fontSize: 13)),
                    const Divider(height: 24),
                    for (final item in order.items)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Row(
                          children: [
                            Text(item.food.emoji),
                            const SizedBox(width: 8),
                            Expanded(child: Text('${item.quantity}× ${item.food.name}')),
                            Text(formatBirr(item.totalPrice)),
                          ],
                        ),
                      ),
                    const Divider(height: 24),
                    _DetailRow('Subtotal', formatBirr(order.subtotal)),
                    _DetailRow('Delivery',
                        order.deliveryFee == 0 ? 'Free' : formatBirr(order.deliveryFee)),
                    if (order.discount > 0)
                      _DetailRow('Discount (${order.promoCode ?? 'promo'})',
                          '-${formatBirr(order.discount)}'),
                    _DetailRow('Total', formatBirr(order.total), bold: true),
                    const Divider(height: 24),
                    _DetailRow('Payment', order.paymentMethod.label),
                    _DetailRow('Address', '${order.address.street}, ${order.address.area}'),
                    if (order.address.instructions.isNotEmpty)
                      _DetailRow('Note', order.address.instructions),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              if (order.status == OrderStatus.confirmed)
                CustomButton(
                  label: 'Cancel order',
                  icon: Icons.close_rounded,
                  variant: ButtonVariant.outline,
                  onPressed: () => _confirmCancel(order),
                ),
              if (!order.isActive)
                CustomButton(
                  label: 'Reorder',
                  icon: Icons.replay_rounded,
                  onPressed: () => CartActions.reorder(context, order),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TimelineStep extends StatelessWidget {
  final OrderStatus status;
  final bool isDone;
  final bool isCurrent;
  final bool isLast;

  const _TimelineStep({
    required this.status,
    required this.isDone,
    required this.isCurrent,
    required this.isLast,
  });

  @override
  Widget build(BuildContext context) {
    final reached = isDone || isCurrent;
    final color = reached ? AppColors.flagGreen : AppColors.mutedOf(context).withAlpha(90);

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 400),
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isDone ? AppColors.flagGreen : Colors.transparent,
                border: Border.all(color: color, width: 2.5),
              ),
              child: isDone
                  ? const Icon(Icons.check_rounded, size: 18, color: Colors.white)
                  : isCurrent
                      ? const Padding(
                          padding: EdgeInsets.all(5),
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: AppColors.flagGreen,
                          ),
                        )
                      : null,
            ),
            if (!isLast)
              AnimatedContainer(
                duration: const Duration(milliseconds: 400),
                width: 3,
                height: 34,
                color: isDone ? AppColors.flagGreen : color,
              ),
          ],
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(top: 3),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  status.label,
                  style: TextStyle(
                    fontWeight: reached ? FontWeight.w800 : FontWeight.w500,
                    color: reached ? null : AppColors.mutedOf(context),
                  ),
                ),
                Text(
                  status.description,
                  style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _DriverCard extends StatelessWidget {
  final bool delivered;

  const _DriverCard({required this.delivered});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Row(
        children: [
          const CircleAvatar(
            radius: 26,
            backgroundColor: AppColors.meskelGold,
            child: Text('🛵', style: TextStyle(fontSize: 26)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Dawit Mekonnen',
                    style: TextStyle(fontWeight: FontWeight.w800)),
                Text(
                  delivered ? 'Delivered your order' : 'Your rider • Plate AA 3-B12345',
                  style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context)),
                ),
              ],
            ),
          ),
          if (!delivered)
            IconButton.filledTonal(
              tooltip: 'Call rider',
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Calling Dawit… (simulated)')),
              ),
              icon: const Icon(Icons.call_rounded),
            ),
        ],
      ),
    );
  }
}

class _DetailRow extends StatelessWidget {
  final String label;
  final String value;
  final bool bold;

  const _DetailRow(this.label, this.value, {this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 110,
            child: Text(label, style: TextStyle(color: AppColors.mutedOf(context))),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                fontWeight: bold ? FontWeight.w900 : FontWeight.w600,
                color: bold ? AppColors.accentOf(context) : null,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
