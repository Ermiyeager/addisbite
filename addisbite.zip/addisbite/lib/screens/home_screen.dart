import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../data/mock_data.dart';
import '../models/food_item.dart';
import '../models/order.dart';
import '../models/promo_code.dart';
import '../models/restaurant.dart';
import '../providers/auth_provider.dart';
import '../providers/cart_provider.dart';
import '../providers/order_provider.dart';
import '../services/restaurant_service.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';
import '../widgets/app_search_bar.dart';
import '../widgets/cart_icon_button.dart';
import '../widgets/category_card.dart';
import '../widgets/custom_button.dart';
import '../widgets/food_card.dart';
import '../widgets/promo_banner.dart';
import '../widgets/restaurant_card.dart';
import '../widgets/section_header.dart';
import 'explore_screen.dart';
import 'main_shell.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  /// Unique dishes from the user's latest orders.
  List<FoodItem> _recentlyOrdered(List<Order> orders) {
    final seen = <String>{};
    final result = <FoodItem>[];
    for (final order in orders) {
      for (final item in order.items) {
        if (seen.add(item.food.id)) result.add(item.food);
        if (result.length == 6) return result;
      }
    }
    return result;
  }

  void _showOffer(BuildContext context, PromoOffer offer) {
    final code = offer.code;
    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(offer.emoji, style: const TextStyle(fontSize: 52)),
              const SizedBox(height: 8),
              Text(offer.title,
                  textAlign: TextAlign.center,
                  style: Theme.of(sheetContext).textTheme.headlineSmall),
              const SizedBox(height: 6),
              Text(offer.subtitle,
                  textAlign: TextAlign.center,
                  style: TextStyle(color: AppColors.mutedOf(sheetContext))),
              const SizedBox(height: 20),
              if (code == null)
                CustomButton(
                  label: 'Start ordering',
                  onPressed: () {
                    Navigator.pop(sheetContext);
                    MainShell.goToTab(1);
                  },
                )
              else ...[
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.meskelGold, width: 2),
                    borderRadius: BorderRadius.circular(16),
                    color: AppColors.meskelGold.withAlpha(30),
                  ),
                  child: Text(
                    code,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 3,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: CustomButton(
                        label: 'Copy',
                        icon: Icons.copy_rounded,
                        variant: ButtonVariant.outline,
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: code));
                          Navigator.pop(sheetContext);
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('$code copied')),
                          );
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: CustomButton(
                        label: 'Apply to cart',
                        icon: Icons.local_offer_rounded,
                        onPressed: () {
                          final error =
                              context.read<CartProvider>().applyPromo(code);
                          Navigator.pop(sheetContext);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text(error ?? '$code applied to your cart'),
                          ));
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final orders = context.watch<OrderProvider>().orders;
    final popularFoods = MockData.foods.where((f) => f.isPopular).toList();
    final ethiopianSpecials =
        MockData.foods.where((f) => f.isEthiopian).take(8).toList();
    final recentFoods = _recentlyOrdered(orders);

    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: CustomScrollView(
          slivers: [
            const SliverToBoxAdapter(child: _HomeHeader()),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                child: AppSearchBar(
                  readOnly: true,
                  onTap: () =>
                      MainShell.shellKey.currentState?.openExploreSearch(),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: PromoBanner(
                offers: MockData.offers,
                onOfferTap: (offer) => _showOffer(context, offer),
              ),
            ),
            const SliverToBoxAdapter(child: SectionHeader(title: 'Categories')),
            SliverToBoxAdapter(
              child: SizedBox(
                height: 92,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: MockData.categories.length,
                  separatorBuilder: (context, index) => const SizedBox(width: 10),
                  itemBuilder: (context, index) {
                    final category = MockData.categories[index];
                    return CategoryCard(
                      category: category,
                      onTap: () => pushScreen(
                        context,
                        ExploreScreen(
                          initialCategoryId: category.id,
                          standalone: true,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Popular restaurants',
                subtitle: 'Loved across Addis this week',
                actionLabel: 'See all',
                onAction: () => MainShell.goToTab(1),
              ),
            ),
            const SliverToBoxAdapter(child: _PopularRestaurants()),
            if (recentFoods.isNotEmpty) ...[
              const SliverToBoxAdapter(
                child: SectionHeader(
                  title: 'Order again',
                  subtitle: 'From your recent orders',
                ),
              ),
              SliverToBoxAdapter(
                child: _HorizontalFoodList(foods: recentFoods, heroPrefix: 'home-recent'),
              ),
            ],
            const SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Popular dishes',
                subtitle: 'What everyone is ordering',
              ),
            ),
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, index) => FoodCard(
                    food: popularFoods[index],
                    heroPrefix: 'home-popular',
                  ),
                  childCount: popularFoods.length,
                ),
                // Responsive: more columns on wider screens and tablets.
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 220,
                  mainAxisExtent: 250,
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                ),
              ),
            ),
            const SliverToBoxAdapter(
              child: SectionHeader(
                title: 'Taste of Ethiopia',
                subtitle: 'Injera classics, recommended for you',
              ),
            ),
            SliverToBoxAdapter(
              child: _HorizontalFoodList(
                  foods: ethiopianSpecials, heroPrefix: 'home-eth'),
            ),
            const SliverToBoxAdapter(child: SizedBox(height: 32)),
          ],
        ),
      ),
    );
  }
}

class _HomeHeader extends StatelessWidget {
  const _HomeHeader();

  void _pickArea(BuildContext context) {
    final auth = context.read<AuthProvider>();
    final current = auth.user?.area;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Deliver to',
                  style: Theme.of(sheetContext).textTheme.titleLarge),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: AppConstants.addisAreas
                    .map((area) => ChoiceChip(
                          label: Text(area),
                          selected: area == current,
                          onSelected: (_) {
                            auth.updateArea(area);
                            Navigator.pop(sheetContext);
                          },
                        ))
                    .toList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    final muted = AppColors.mutedOf(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 8, 4),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => MainShell.goToTab(4),
            child: CircleAvatar(
              radius: 24,
              backgroundColor: AppColors.flagGreen,
              child: Text(
                user?.initials ?? '?',
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${greetingForNow()}, ${user?.firstName ?? 'friend'}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => _pickArea(context),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 2),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.location_on_rounded,
                            size: 16, color: AppColors.accentOf(context)),
                        const SizedBox(width: 2),
                        Flexible(
                          child: Text(
                            '${user?.area ?? 'Bole'}, Addis Ababa',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: muted, fontSize: 13),
                          ),
                        ),
                        Icon(Icons.keyboard_arrow_down_rounded,
                            size: 18, color: muted),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const CartIconButton(),
        ],
      ),
    );
  }
}

/// Loads restaurants with a FutureBuilder to demonstrate async loading.
class _PopularRestaurants extends StatefulWidget {
  const _PopularRestaurants();

  @override
  State<_PopularRestaurants> createState() => _PopularRestaurantsState();
}

class _PopularRestaurantsState extends State<_PopularRestaurants> {
  late Future<List<Restaurant>> _future = RestaurantService.fetchRestaurants();

  void _retry() =>
      setState(() => _future = RestaurantService.fetchRestaurants());

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 222,
      child: FutureBuilder<List<Restaurant>>(
        future: _future,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: 3,
              separatorBuilder: (context, index) => const SizedBox(width: 12),
              itemBuilder: (context, index) => Container(
                width: 270,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(24),
                ),
                alignment: Alignment.center,
                child: const CircularProgressIndicator(),
              ),
            );
          }
          if (snapshot.hasError) {
            return Center(
              child: TextButton.icon(
                onPressed: _retry,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Could not load restaurants. Tap to retry.'),
              ),
            );
          }

          final restaurants = [...(snapshot.data ?? <Restaurant>[])]
            ..sort((a, b) => b.popularity.compareTo(a.popularity));

          return ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: restaurants.length,
            separatorBuilder: (context, index) => const SizedBox(width: 12),
            itemBuilder: (context, index) => RestaurantCard(
              restaurant: restaurants[index],
              heroPrefix: 'home-rest',
              width: 270,
            ),
          );
        },
      ),
    );
  }
}

class _HorizontalFoodList extends StatelessWidget {
  final List<FoodItem> foods;
  final String heroPrefix;

  const _HorizontalFoodList({required this.foods, required this.heroPrefix});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 240,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: foods.length,
        separatorBuilder: (context, index) => const SizedBox(width: 12),
        itemBuilder: (context, index) => FoodCard(
          food: foods[index],
          heroPrefix: heroPrefix,
          width: 168,
        ),
      ),
    );
  }
}
