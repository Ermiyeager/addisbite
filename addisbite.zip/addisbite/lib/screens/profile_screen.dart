import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../providers/auth_provider.dart';
import '../providers/favorites_provider.dart';
import '../providers/order_provider.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';
import '../widgets/tibeb_stripe.dart';
import 'auth/login_screen.dart';
import 'edit_profile_screen.dart';
import 'main_shell.dart';
import 'settings_screen.dart';

/// Shows a confirmation dialog, then logs out and returns to login.
/// Public so the Settings screen can reuse it.
Future<void> confirmLogout(BuildContext context) async {
  final auth = context.read<AuthProvider>();
  final navigator = Navigator.of(context);
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (dialogContext) => AlertDialog(
      title: const Text('Log out?'),
      content: const Text('Your cart and favourites stay saved on this phone.'),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(dialogContext, false),
          child: const Text('Stay'),
        ),
        TextButton(
          onPressed: () => Navigator.pop(dialogContext, true),
          child: const Text('Log out'),
        ),
      ],
    ),
  );
  if (confirmed != true) return;
  await auth.logout();
  navigator.pushAndRemoveUntil(
    buildRoute(const LoginScreen()),
    (route) => false,
  );
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final user = context.watch<AuthProvider>().user;
    final orders = context.watch<OrderProvider>();
    final favoritesCount = context.watch<FavoritesProvider>().count;

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 720),
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: AppColors.berbereGradient,
                  borderRadius: BorderRadius.circular(26),
                ),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: Row(
                        children: [
                          CircleAvatar(
                            radius: 34,
                            backgroundColor: AppColors.teff,
                            child: Text(
                              user?.initials ?? '?',
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.w900,
                                color: AppColors.berbere,
                              ),
                            ),
                          ),
                          const SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  user?.name ?? 'Guest',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 20,
                                    fontWeight: FontWeight.w900,
                                  ),
                                ),
                                const SizedBox(height: 2),
                                Text(user?.email ?? '',
                                    style: TextStyle(color: Colors.white.withAlpha(230))),
                                Text(user?.phone ?? '',
                                    style: TextStyle(color: Colors.white.withAlpha(230))),
                              ],
                            ),
                          ),
                          IconButton(
                            tooltip: 'Edit profile',
                            color: Colors.white,
                            onPressed: () =>
                                pushScreen(context, const EditProfileScreen()),
                            icon: const Icon(Icons.edit_rounded),
                          ),
                        ],
                      ),
                    ),
                    const TibebStripe(height: 10),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _StatCard(
                      value: '${orders.orders.length}',
                      label: 'Orders',
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _StatCard(value: '$favoritesCount', label: 'Favorites'),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: _StatCard(
                      value: formatBirr(orders.totalSpent),
                      label: 'Spent',
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              _MenuGroup(
                children: [
                  _MenuTile(
                    icon: Icons.location_on_outlined,
                    title: 'Delivery address',
                    subtitle: user?.fullAddress ?? 'Not set',
                    onTap: () => pushScreen(context, const EditProfileScreen()),
                  ),
                  _MenuTile(
                    icon: Icons.receipt_long_outlined,
                    title: 'Order history',
                    onTap: () => MainShell.goToTab(2),
                  ),
                  _MenuTile(
                    icon: Icons.favorite_border_rounded,
                    title: 'Favorites',
                    onTap: () => MainShell.goToTab(3),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              _MenuGroup(
                children: [
                  _MenuTile(
                    icon: Icons.settings_outlined,
                    title: 'Settings',
                    onTap: () => pushScreen(context, const SettingsScreen()),
                  ),
                  _MenuTile(
                    icon: Icons.help_outline_rounded,
                    title: 'Help and support',
                    onTap: () => showDialog<void>(
                      context: context,
                      builder: (dialogContext) => AlertDialog(
                        title: const Text('Help and support'),
                        content: const Text(
                          'Call 8888 or email help@addisbite.et.\n'
                          'We answer every day from 7:00 AM to 11:00 PM.',
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(dialogContext),
                            child: const Text('Close'),
                          ),
                        ],
                      ),
                    ),
                  ),
                  _MenuTile(
                    icon: Icons.logout_rounded,
                    title: 'Log out',
                    color: AppColors.error,
                    onTap: () => confirmLogout(context),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value;
  final String label;

  const _StatCard({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: [
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: AppColors.accentOf(context),
              ),
            ),
          ),
          const SizedBox(height: 2),
          Text(label,
              style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context))),
        ],
      ),
    );
  }
}

class _MenuGroup extends StatelessWidget {
  final List<Widget> children;

  const _MenuGroup({required this.children});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).colorScheme.surface,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: Column(children: children),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String? subtitle;
  final VoidCallback onTap;
  final Color? color;

  const _MenuTile({
    required this.icon,
    required this.title,
    required this.onTap,
    this.subtitle,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final sub = subtitle;
    return ListTile(
      leading: Icon(icon, color: color),
      title: Text(title,
          style: TextStyle(color: color, fontWeight: FontWeight.w600)),
      subtitle: sub == null ? null : Text(sub, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: onTap,
    );
  }
}
