import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../providers/favorites_provider.dart';

enum FavoriteType { restaurant, food }

/// Heart button that "pops" when tapped. Reads and updates FavoritesProvider.
class FavoriteButton extends StatefulWidget {
  final String id;
  final FavoriteType type;
  final double size;

  const FavoriteButton({
    super.key,
    required this.id,
    required this.type,
    this.size = 22,
  });

  @override
  State<FavoriteButton> createState() => _FavoriteButtonState();
}

class _FavoriteButtonState extends State<FavoriteButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 350),
  );

  late final Animation<double> _scale = TweenSequence<double>([
    TweenSequenceItem(tween: Tween<double>(begin: 1, end: 1.35), weight: 50),
    TweenSequenceItem(tween: Tween<double>(begin: 1.35, end: 1), weight: 50),
  ]).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _toggle() {
    final favorites = context.read<FavoritesProvider>();
    final nowFavorite = widget.type == FavoriteType.restaurant
        ? favorites.toggleRestaurant(widget.id)
        : favorites.toggleFood(widget.id);
    _controller.forward(from: 0);

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(nowFavorite ? 'Saved to favorites' : 'Removed from favorites'),
        duration: const Duration(milliseconds: 1200),
      ));
  }

  @override
  Widget build(BuildContext context) {
    final favorites = context.watch<FavoritesProvider>();
    final isFavorite = widget.type == FavoriteType.restaurant
        ? favorites.isRestaurantFavorite(widget.id)
        : favorites.isFoodFavorite(widget.id);

    return Semantics(
      button: true,
      label: isFavorite ? 'Remove from favorites' : 'Add to favorites',
      excludeSemantics: true,
      child: Material(
        color: Theme.of(context).colorScheme.surface.withAlpha(235),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: _toggle,
          child: Padding(
            padding: const EdgeInsets.all(9),
            child: ScaleTransition(
              scale: _scale,
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 250),
                transitionBuilder: (child, animation) =>
                    ScaleTransition(scale: animation, child: child),
                child: Icon(
                  isFavorite
                      ? Icons.favorite_rounded
                      : Icons.favorite_border_rounded,
                  key: ValueKey<bool>(isFavorite),
                  color: isFavorite
                      ? AppColors.berbere
                      : Theme.of(context).colorScheme.onSurface.withAlpha(170),
                  size: widget.size,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
