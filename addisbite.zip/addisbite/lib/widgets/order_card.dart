import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../models/order.dart';
import '../screens/order_tracking_screen.dart';
import '../services/restaurant_service.dart';
import '../utils/cart_actions.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';

class OrderCard extends StatelessWidget {
  final Order order;

  const OrderCard({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = AppColors.mutedOf(context);
    final restaurant = RestaurantService.findRestaurant(order.restaurantId);

    return Material(
      color: theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(22),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => pushScreen(context, OrderTrackingScreen(orderId: order.id)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: (restaurant?.gradient.first ?? AppColors.berbere)
                          .withAlpha(35),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(restaurant?.logoEmoji ?? '🍽️',
                        style: const TextStyle(fontSize: 22)),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          order.restaurantName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.titleSmall,
                        ),
                        Text(
                          '${order.id} • ${formatDate(order.createdAt)}',
                          style: TextStyle(fontSize: 12, color: muted),
                        ),
                      ],
                    ),
                  ),
                  OrderStatusChip(status: order.status),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                order.itemsSummary,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color: muted, height: 1.3),
              ),
              const Divider(height: 22),
              Row(
                children: [
                  Expanded(
                    child: Text(
                      formatBirr(order.total),
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        color: AppColors.accentOf(context),
                      ),
                    ),
                  ),
                  if (order.isActive)
                    TextButton.icon(
                      onPressed: () => pushScreen(
                          context, OrderTrackingScreen(orderId: order.id)),
                      icon: const Icon(Icons.delivery_dining_rounded),
                      label: const Text('Track'),
                    )
                  else
                    TextButton.icon(
                      onPressed: () => CartActions.reorder(context, order),
                      icon: const Icon(Icons.replay_rounded),
                      label: const Text('Reorder'),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class OrderStatusChip extends StatelessWidget {
  final OrderStatus status;

  const OrderStatusChip({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    final Color color = switch (status) {
      OrderStatus.delivered => AppColors.flagGreen,
      OrderStatus.cancelled => AppColors.error,
      _ => const Color(0xFFB8680A),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withAlpha(30),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(status.icon, size: 14, color: color),
          const SizedBox(width: 4),
          Text(
            status.label,
            style: TextStyle(
              color: color,
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }
}
