import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../models/restaurant.dart';
import '../utils/formatters.dart';
import '../utils/navigation.dart';
import 'favorite_button.dart';
import 'food_visual.dart';
import 'rating_widget.dart';

class RestaurantCard extends StatelessWidget {
  final Restaurant restaurant;

  /// Must be unique per list on a screen, so Hero tags never clash.
  final String heroPrefix;
  final double? width;

  const RestaurantCard({
    super.key,
    required this.restaurant,
    required this.heroPrefix,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final muted = AppColors.mutedOf(context);
    final heroTag = '$heroPrefix-restaurant-${restaurant.id}';

    return SizedBox(
      width: width,
      child: Material(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(24),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => openRestaurant(context, restaurant, heroTag: heroTag),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                height: 128,
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: FoodVisual(
                        emoji: restaurant.coverEmoji,
                        colors: restaurant.gradient,
                        emojiSize: 58,
                        borderRadius: 0,
                        heroTag: heroTag,
                      ),
                    ),
                    if (!restaurant.isOpen)
                      Positioned.fill(
                        child: Container(
                          color: Colors.black.withAlpha(130),
                          alignment: Alignment.center,
                          child: const _Pill(
                            icon: Icons.nightlight_round,
                            text: 'Closed now',
                            background: Colors.white,
                            foreground: AppColors.charcoal,
                          ),
                        ),
                      ),
                    Positioned(
                      top: 8,
                      right: 8,
                      child: FavoriteButton(
                        id: restaurant.id,
                        type: FavoriteType.restaurant,
                        size: 20,
                      ),
                    ),
                    Positioned(
                      left: 10,
                      bottom: 10,
                      child: _Pill(
                        icon: Icons.schedule_rounded,
                        text: restaurant.deliveryTimeLabel,
                        background: Colors.white,
                        foreground: AppColors.charcoal,
                      ),
                    ),
                    if (restaurant.hasFreeDelivery)
                      const Positioned(
                        right: 10,
                        bottom: 10,
                        child: _Pill(
                          icon: Icons.local_offer_rounded,
                          text: 'Free delivery',
                          background: AppColors.meskelGold,
                          foreground: AppColors.charcoal,
                        ),
                      ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(restaurant.logoEmoji,
                            style: const TextStyle(fontSize: 20)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            restaurant.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleMedium,
                          ),
                        ),
                        RatingWidget(rating: restaurant.rating, compact: true),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.location_on_rounded, size: 15, color: muted),
                        const SizedBox(width: 2),
                        Flexible(
                          child: Text(
                            restaurant.location,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: muted, fontSize: 13),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Icon(Icons.delivery_dining_rounded, size: 16, color: muted),
                        const SizedBox(width: 3),
                        Flexible(
                          child: Text(
                            restaurant.hasFreeDelivery
                                ? 'Free'
                                : formatBirr(restaurant.deliveryFee),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: muted, fontSize: 13),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color background;
  final Color foreground;

  const _Pill({
    required this.icon,
    required this.text,
    required this.background,
    required this.foreground,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: foreground),
          const SizedBox(width: 4),
          Text(
            text,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: foreground,
            ),
          ),
        ],
      ),
    );
  }
}
