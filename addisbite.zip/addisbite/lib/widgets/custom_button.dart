import 'package:flutter/material.dart';

import '../constants/app_colors.dart';

enum ButtonVariant { primary, secondary, outline }

/// One button style for the whole app, with a built-in loading state.
class CustomButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool isLoading;
  final ButtonVariant variant;
  final bool expanded;

  const CustomButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.isLoading = false,
    this.variant = ButtonVariant.primary,
    this.expanded = true,
  });

  @override
  Widget build(BuildContext context) {
    final buttonIcon = icon;
    final Widget child = isLoading
        ? SizedBox(
            width: 22,
            height: 22,
            child: CircularProgressIndicator(
              strokeWidth: 2.5,
              color: variant == ButtonVariant.outline
                  ? Theme.of(context).colorScheme.primary
                  : Colors.white,
            ),
          )
        : Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (buttonIcon != null) ...[
                Icon(buttonIcon, size: 20),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis),
              ),
            ],
          );

    final VoidCallback? action = isLoading ? null : onPressed;

    final Widget button = switch (variant) {
      ButtonVariant.primary => ElevatedButton(onPressed: action, child: child),
      ButtonVariant.secondary => ElevatedButton(
          onPressed: action,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.flagGreen,
            foregroundColor: Colors.white,
          ),
          child: child,
        ),
      ButtonVariant.outline => OutlinedButton(onPressed: action, child: child),
    };

    return expanded ? SizedBox(width: double.infinity, child: button) : button;
  }
}
