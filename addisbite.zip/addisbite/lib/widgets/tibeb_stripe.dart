import 'package:flutter/material.dart';

import '../constants/app_colors.dart';

/// A woven "tibeb" border, inspired by the patterned hem of the habesha kemis.
/// It is AddisBite's signature decoration, drawn with a CustomPainter.
class TibebStripe extends StatelessWidget {
  final double height;

  const TibebStripe({super.key, this.height = 10});

  @override
  Widget build(BuildContext context) {
    return ExcludeSemantics(
      child: SizedBox(
        height: height,
        width: double.infinity,
        child: CustomPaint(painter: _TibebPainter()),
      ),
    );
  }
}

class _TibebPainter extends CustomPainter {
  static const List<Color> _colors = [
    AppColors.flagGreen,
    AppColors.meskelGold,
    AppColors.berbere,
  ];

  @override
  void paint(Canvas canvas, Size size) {
    final double w = size.height * 1.4;
    var index = 0;
    for (double x = 0; x < size.width; x += w) {
      final paint = Paint()..color = _colors[index % _colors.length];
      final path = Path()
        ..moveTo(x + w / 2, 0)
        ..lineTo(x + w, size.height / 2)
        ..lineTo(x + w / 2, size.height)
        ..lineTo(x, size.height / 2)
        ..close();
      canvas.drawPath(path, paint);
      index++;
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
