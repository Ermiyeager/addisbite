import 'package:flutter/material.dart';

import '../constants/app_colors.dart';

class RatingWidget extends StatelessWidget {
  final double rating;
  final int? reviewCount;
  final bool compact;
  final Color? textColor;

  const RatingWidget({
    super.key,
    required this.rating,
    this.reviewCount,
    this.compact = false,
    this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    final color = textColor ?? Theme.of(context).colorScheme.onSurface;
    final count = reviewCount;
    return Semantics(
      label: 'Rated ${rating.toStringAsFixed(1)} out of 5',
      excludeSemantics: true,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.star_rounded,
              color: AppColors.meskelGold, size: compact ? 16 : 19),
          const SizedBox(width: 3),
          Text(
            rating.toStringAsFixed(1),
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: compact ? 13 : 14,
              color: color,
            ),
          ),
          if (count != null)
            Text(
              ' ($count)',
              style: TextStyle(fontSize: compact ? 12 : 13, color: color.withAlpha(160)),
            ),
        ],
      ),
    );
  }
}
