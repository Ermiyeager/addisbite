import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import 'custom_button.dart';

/// Friendly message shown instead of a blank screen.
class EmptyState extends StatelessWidget {
  final String emoji;
  final String title;
  final String message;
  final String? actionLabel;
  final VoidCallback? onAction;

  const EmptyState({
    super.key,
    required this.emoji,
    required this.title,
    required this.message,
    this.actionLabel,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    final label = actionLabel;
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 120,
              height: 120,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.meskelGold.withAlpha(45),
              ),
              child: Text(emoji, style: const TextStyle(fontSize: 56)),
            ),
            const SizedBox(height: 20),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(
              message,
              textAlign: TextAlign.center,
              style: TextStyle(color: AppColors.mutedOf(context), height: 1.4),
            ),
            if (label != null && onAction != null) ...[
              const SizedBox(height: 24),
              CustomButton(label: label, onPressed: onAction, expanded: false),
            ],
          ],
        ),
      ),
    );
  }
}
