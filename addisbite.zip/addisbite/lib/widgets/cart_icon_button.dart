import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../providers/cart_provider.dart';
import '../screens/cart_screen.dart';
import '../utils/navigation.dart';

/// Cart icon with an animated item-count badge.
class CartIconButton extends StatelessWidget {
  final Color? color;

  const CartIconButton({super.key, this.color});

  @override
  Widget build(BuildContext context) {
    final count = context.watch<CartProvider>().itemCount;
    return IconButton(
      tooltip: count == 0 ? 'Cart' : 'Cart, $count items',
      onPressed: () => pushScreen(context, const CartScreen()),
      icon: Stack(
        clipBehavior: Clip.none,
        children: [
          Icon(Icons.shopping_bag_outlined, color: color, size: 26),
          Positioned(
            right: -8,
            top: -6,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 250),
              transitionBuilder: (child, animation) =>
                  ScaleTransition(scale: animation, child: child),
              child: count == 0
                  ? const SizedBox.shrink(key: ValueKey<int>(0))
                  : Container(
                      key: ValueKey<int>(count),
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: AppColors.meskelGold,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        '$count',
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w900,
                          color: AppColors.charcoal,
                        ),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}
