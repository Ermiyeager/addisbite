import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../utils/formatters.dart';

class PriceWidget extends StatelessWidget {
  final double amount;
  final double fontSize;
  final Color? color;

  const PriceWidget({
    super.key,
    required this.amount,
    this.fontSize = 16,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      formatBirr(amount),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: FontWeight.w800,
        color: color ?? AppColors.accentOf(context),
      ),
    );
  }
}

/// A price that counts up/down smoothly when the amount changes.
class AnimatedPrice extends StatelessWidget {
  final double amount;
  final TextStyle? style;

  const AnimatedPrice({super.key, required this.amount, this.style});

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(end: amount),
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeOutCubic,
      builder: (context, value, child) => Text(formatBirr(value), style: style),
    );
  }
}
