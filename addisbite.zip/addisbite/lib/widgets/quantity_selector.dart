import 'package:flutter/material.dart';

class QuantitySelector extends StatelessWidget {
  final int quantity;
  final VoidCallback onIncrement;
  final VoidCallback onDecrement;
  final bool canDecrement;
  final bool compact;

  const QuantitySelector({
    super.key,
    required this.quantity,
    required this.onIncrement,
    required this.onDecrement,
    this.canDecrement = true,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Container(
      decoration: BoxDecoration(
        color: primary.withAlpha(25),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            tooltip: 'Decrease quantity',
            onPressed: canDecrement ? onDecrement : null,
            color: primary,
            visualDensity: compact ? VisualDensity.compact : null,
            icon: Icon(Icons.remove_rounded, size: compact ? 18 : 22),
          ),
          SizedBox(
            width: compact ? 22 : 30,
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              transitionBuilder: (child, animation) =>
                  ScaleTransition(scale: animation, child: child),
              child: Text(
                '$quantity',
                key: ValueKey<int>(quantity),
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                  fontSize: compact ? 15 : 18,
                ),
              ),
            ),
          ),
          IconButton(
            tooltip: 'Increase quantity',
            onPressed: onIncrement,
            color: primary,
            visualDensity: compact ? VisualDensity.compact : null,
            icon: Icon(Icons.add_rounded, size: compact ? 18 : 22),
          ),
        ],
      ),
    );
  }
}
