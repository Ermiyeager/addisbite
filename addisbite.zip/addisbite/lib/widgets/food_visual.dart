import 'package:flutter/material.dart';

/// Colourful gradient tile with a food emoji. Used instead of photos so the
/// app works fully offline and needs no image assets.
class FoodVisual extends StatelessWidget {
  final String emoji;
  final List<Color> colors;
  final double? width;
  final double? height;
  final double emojiSize;
  final double borderRadius;
  final String? heroTag;
  final bool showPattern;

  const FoodVisual({
    super.key,
    required this.emoji,
    required this.colors,
    this.width,
    this.height,
    this.emojiSize = 48,
    this.borderRadius = 20,
    this.heroTag,
    this.showPattern = true,
  });

  @override
  Widget build(BuildContext context) {
    Widget visual = Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(borderRadius),
        gradient: LinearGradient(
          colors: colors,
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(borderRadius),
        child: Stack(
          children: [
            if (showPattern) ...[
              Positioned(right: -24, top: -24, child: _circle(emojiSize * 1.8)),
              Positioned(left: -30, bottom: -34, child: _circle(emojiSize * 1.5)),
            ],
            Center(
              child: Text(
                emoji,
                style: TextStyle(fontSize: emojiSize),
                semanticsLabel: '',
              ),
            ),
          ],
        ),
      ),
    );

    final tag = heroTag;
    if (tag != null) {
      // Hero animates the tile from a card into the details screen.
      visual = Hero(
        tag: tag,
        child: Material(type: MaterialType.transparency, child: visual),
      );
    }
    return visual;
  }

  Widget _circle(double size) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withAlpha(38),
        ),
      );
}
