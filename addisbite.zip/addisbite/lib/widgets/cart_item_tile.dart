import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../constants/app_colors.dart';
import '../data/mock_data.dart';
import '../models/cart_item.dart';
import '../providers/cart_provider.dart';
import 'food_visual.dart';
import 'price_widget.dart';
import 'quantity_selector.dart';

/// A cart line. Swipe left to delete (with Undo).
class CartItemTile extends StatelessWidget {
  final CartItem item;

  const CartItemTile({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final cart = context.read<CartProvider>();
    final theme = Theme.of(context);
    final extras = item.selectedExtras.map((e) => e.name).join(', ');
    final note = item.note;

    return Dismissible(
      key: ValueKey<String>(item.id),
      direction: DismissDirection.endToStart,
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        decoration: BoxDecoration(
          color: AppColors.error,
          borderRadius: BorderRadius.circular(20),
        ),
        child: const Icon(Icons.delete_rounded, color: Colors.white),
      ),
      onDismissed: (_) {
        final index = cart.remove(item.id);
        ScaffoldMessenger.of(context)
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(
            content: Text('${item.food.name} removed'),
            action: SnackBarAction(
              label: 'Undo',
              onPressed: () => cart.restore(item, index),
            ),
          ));
      },
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            FoodVisual(
              emoji: item.food.emoji,
              colors: MockData.gradientForCategory(item.food.categoryId),
              width: 70,
              height: 70,
              emojiSize: 34,
              borderRadius: 14,
              showPattern: false,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.food.name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: theme.textTheme.titleSmall,
                  ),
                  if (extras.isNotEmpty)
                    Text(
                      '+ $extras',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context)),
                    ),
                  if (note != null)
                    Text(
                      '“$note”',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontSize: 12,
                        fontStyle: FontStyle.italic,
                        color: AppColors.mutedOf(context),
                      ),
                    ),
                  const SizedBox(height: 4),
                  AnimatedPrice(
                    amount: item.totalPrice,
                    style: TextStyle(
                      fontWeight: FontWeight.w800,
                      color: AppColors.accentOf(context),
                    ),
                  ),
                ],
              ),
            ),
            QuantitySelector(
              quantity: item.quantity,
              compact: true,
              onIncrement: () => cart.increment(item.id),
              onDecrement: () => cart.decrement(item.id),
            ),
          ],
        ),
      ),
    );
  }
}
