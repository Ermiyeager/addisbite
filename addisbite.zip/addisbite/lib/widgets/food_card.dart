import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../data/mock_data.dart';
import '../models/food_item.dart';
import '../services/restaurant_service.dart';
import '../utils/cart_actions.dart';
import '../utils/navigation.dart';
import 'favorite_button.dart';
import 'food_visual.dart';
import 'price_widget.dart';
import 'rating_widget.dart';

/// Vertical card used in grids and horizontal lists.
class FoodCard extends StatelessWidget {
  final FoodItem food;
  final String heroPrefix;
  final double? width;

  const FoodCard({
    super.key,
    required this.food,
    required this.heroPrefix,
    this.width,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final restaurant = RestaurantService.findRestaurant(food.restaurantId);
    final heroTag = '$heroPrefix-food-${food.id}';

    return SizedBox(
      width: width,
      child: Material(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(22),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => openFood(context, food, heroTag: heroTag),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: Stack(
                    children: [
                      Positioned.fill(
                        child: FoodVisual(
                          emoji: food.emoji,
                          colors: MockData.gradientForCategory(food.categoryId),
                          emojiSize: 50,
                          borderRadius: 16,
                          heroTag: heroTag,
                        ),
                      ),
                      Positioned(
                        top: 6,
                        right: 6,
                        child: FavoriteButton(
                            id: food.id, type: FavoriteType.food, size: 18),
                      ),
                      if (food.isSpicy)
                        const Positioned(
                          top: 8,
                          left: 8,
                          child: FoodTag(text: '🌶️ Spicy'),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  food.name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: theme.textTheme.titleSmall,
                ),
                const SizedBox(height: 2),
                Text(
                  restaurant?.name ?? '',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(fontSize: 12, color: AppColors.mutedOf(context)),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: PriceWidget(amount: food.price, fontSize: 15)),
                    AddIconButton(
                      enabled: restaurant?.isOpen ?? true,
                      onTap: () => CartActions.addToCart(context, food),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Horizontal row used in menus, search results and favourites.
class FoodListTile extends StatelessWidget {
  final FoodItem food;
  final String heroPrefix;
  final bool showRestaurant;

  const FoodListTile({
    super.key,
    required this.food,
    required this.heroPrefix,
    this.showRestaurant = false,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final heroTag = '$heroPrefix-food-${food.id}';
    final restaurant = RestaurantService.findRestaurant(food.restaurantId);
    final subtitle = showRestaurant && restaurant != null
        ? '${restaurant.name} • ${restaurant.location}'
        : food.description;

    return Material(
      color: theme.colorScheme.surface,
      borderRadius: BorderRadius.circular(20),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: () => openFood(context, food, heroTag: heroTag),
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              FoodVisual(
                emoji: food.emoji,
                colors: MockData.gradientForCategory(food.categoryId),
                width: 86,
                height: 86,
                emojiSize: 40,
                borderRadius: 16,
                heroTag: heroTag,
                showPattern: false,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            food.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.titleSmall,
                          ),
                        ),
                        if (food.isSpicy)
                          const Text('🌶️', semanticsLabel: 'Spicy'),
                        if (food.isVegetarian)
                          const Text(' 🌱', semanticsLabel: 'Vegetarian'),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 12.5,
                          color: AppColors.mutedOf(context),
                          height: 1.3),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Flexible(child: PriceWidget(amount: food.price, fontSize: 15)),
                        const SizedBox(width: 10),
                        RatingWidget(rating: food.rating, compact: true),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              AddIconButton(
                enabled: restaurant?.isOpen ?? true,
                onTap: () => CartActions.addToCart(context, food),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class AddIconButton extends StatelessWidget {
  final VoidCallback onTap;
  final bool enabled;

  const AddIconButton({super.key, required this.onTap, this.enabled = true});

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;
    return Semantics(
      button: true,
      enabled: enabled,
      label: enabled ? 'Add to cart' : 'Restaurant closed',
      excludeSemantics: true,
      child: Material(
        color: enabled ? primary : Colors.grey.withAlpha(120),
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: onTap, // Closed restaurants still show a helpful SnackBar.
          child: SizedBox(
            width: 40,
            height: 40,
            child: Icon(
              enabled ? Icons.add_rounded : Icons.lock_clock_rounded,
              color: Colors.white,
              size: 22,
            ),
          ),
        ),
      ),
    );
  }
}

class FoodTag extends StatelessWidget {
  final String text;
  final Color? color;

  const FoodTag({super.key, required this.text, this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color ?? Colors.white.withAlpha(235),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        text,
        style: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          color: AppColors.charcoal,
        ),
      ),
    );
  }
}
