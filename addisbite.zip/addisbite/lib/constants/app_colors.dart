import 'package:flutter/material.dart';

/// AddisBite colour palette, inspired by Ethiopian food and culture.
///
/// * Berbere red   – the spice blend in Doro Wat and Tibs (primary actions)
/// * Flag green    – the green of the Ethiopian flag (success, "open", secondary)
/// * Meskel gold   – the yellow Meskel daisy (ratings, offers, highlights)
/// * Buna brown    – the coffee ceremony (warm accents)
/// * Teff          – warm grain colour used instead of plain white
class AppColors {
  AppColors._(); // Private constructor: this class only holds constants.

  static const Color berbere = Color(0xFFC0282D);
  static const Color berbereDeep = Color(0xFF8E1B20);
  static const Color berbereLight = Color(0xFFEF5A4C);
  static const Color flagGreen = Color(0xFF11694A);
  static const Color flagGreenLight = Color(0xFF2E9A6C);
  static const Color meskelGold = Color(0xFFF4B41A);
  static const Color buna = Color(0xFF5B3A29);
  static const Color teff = Color(0xFFFAF1E1);
  static const Color charcoal = Color(0xFF211B18);
  static const Color darkSurface = Color(0xFF16110F);
  static const Color darkCard = Color(0xFF261D19);
  static const Color error = Color(0xFFC62828);

  static const LinearGradient berbereGradient = LinearGradient(
    colors: [berbereDeep, berbere, berbereLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient greenGradient = LinearGradient(
    colors: [flagGreen, flagGreenLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient goldGradient = LinearGradient(
    colors: [Color(0xFFD9820F), meskelGold],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  /// Secondary text colour that works in both light and dark mode.
  static Color mutedOf(BuildContext context) =>
      Theme.of(context).colorScheme.onSurface.withAlpha(165);

  /// Price / accent colour with good contrast in both modes.
  static Color accentOf(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark ? berbereLight : berbere;
}
