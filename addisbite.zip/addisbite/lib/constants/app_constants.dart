/// App-wide constant values.
class AppConstants {
  AppConstants._();

  static const String appName = 'AddisBite';
  static const String tagline = 'Taste Addis, One Bite at a Time.';
  static const String version = '1.0.0';

  static const String currencySymbol = 'ብር';
  static const String currencyCode = 'ETB';

  /// Orders above this subtotal get free delivery.
  static const double freeDeliveryThreshold = 1500;

  /// Demo account so the app can be shown without registering.
  static const String demoEmail = 'ermias@addisbite.et';
  static const String demoPassword = 'addis123';

  static const List<String> addisAreas = [
    'Bole',
    'Kazanchis',
    'Piassa',
    'Merkato',
    'Megenagna',
    'CMC',
    'Gerji',
    'Saris',
    'Mexico',
    '4 Kilo',
    'Yeka',
    'Lideta',
  ];

  static const List<String> languages = ['English', 'አማርኛ', 'Afaan Oromoo'];
}

/// Keys used for SharedPreferences, kept in one place to avoid typos.
class StorageKeys {
  StorageKeys._();

  static const String isLoggedIn = 'is_logged_in';
  static const String currentUser = 'current_user';
  static const String accounts = 'accounts';
  static const String cart = 'cart_items';
  static const String orders = 'orders';
  static const String favoriteRestaurants = 'favorite_restaurants';
  static const String favoriteFoods = 'favorite_foods';
  static const String darkMode = 'dark_mode';
  static const String notifications = 'notifications';
  static const String language = 'language';
  static const String searchHistory = 'search_history';
}
