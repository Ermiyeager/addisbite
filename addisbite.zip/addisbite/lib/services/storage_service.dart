import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// A thin wrapper around SharedPreferences.
/// Every screen and provider goes through this class, so local storage
/// lives in one place and is easy to explain or replace later.
class StorageService {
  StorageService._(); // Singleton: only one instance exists.
  static final StorageService instance = StorageService._();

  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }

  SharedPreferences get _p {
    final prefs = _prefs;
    if (prefs == null) {
      throw StateError('StorageService.init() must be called before use.');
    }
    return prefs;
  }

  Future<bool> setString(String key, String value) => _p.setString(key, value);
  String? getString(String key) => _p.getString(key);

  Future<bool> setBool(String key, bool value) => _p.setBool(key, value);
  bool? getBool(String key) => _p.getBool(key);

  Future<bool> setStringList(String key, List<String> value) =>
      _p.setStringList(key, value);
  List<String>? getStringList(String key) => _p.getStringList(key);

  Future<bool> remove(String key) => _p.remove(key);

  /// Saves any Map/List as a JSON string.
  Future<bool> setJson(String key, Object value) =>
      setString(key, jsonEncode(value));

  /// Reads JSON back. Returns null if nothing is saved or the data is broken.
  dynamic getJson(String key) {
    final raw = getString(key);
    if (raw == null) return null;
    try {
      return jsonDecode(raw);
    } on FormatException catch (e) {
      debugPrint('Could not decode "$key": $e');
      return null;
    }
  }
}
