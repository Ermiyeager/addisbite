import '../constants/app_constants.dart';
import 'storage_service.dart';

/// Remembers the last few searches so they can be tapped again.
class SearchHistoryService {
  SearchHistoryService._();

  static const int maxEntries = 8;

  static List<String> load() =>
      StorageService.instance.getStringList(StorageKeys.searchHistory) ?? [];

  static Future<void> save(List<String> history) => StorageService.instance
      .setStringList(StorageKeys.searchHistory, history.take(maxEntries).toList());

  static Future<void> clear() =>
      StorageService.instance.remove(StorageKeys.searchHistory);
}
