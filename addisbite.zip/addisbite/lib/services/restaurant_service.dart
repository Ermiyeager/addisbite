import '../data/mock_data.dart';
import '../models/category.dart';
import '../models/food_item.dart';
import '../models/restaurant.dart';
import '../models/review.dart';

enum SortOption { popular, highestRated, lowestPrice, fastestDelivery }

extension SortOptionLabel on SortOption {
  String get label => switch (this) {
        SortOption.popular => 'Most popular',
        SortOption.highestRated => 'Highest rated',
        SortOption.lowestPrice => 'Lowest price',
        SortOption.fastestDelivery => 'Fastest delivery',
      };
}

/// The filters chosen on the Explore screen.
class RestaurantFilter {
  final String? categoryId;
  final double? maxPrice;
  final double minRating;
  final int? maxDeliveryMinutes;
  final String? location;
  final SortOption sort;

  const RestaurantFilter({
    this.categoryId,
    this.maxPrice,
    this.minRating = 0,
    this.maxDeliveryMinutes,
    this.location,
    this.sort = SortOption.popular,
  });

  /// Number of active filters (sorting does not count).
  int get activeCount {
    var count = 0;
    if (categoryId != null) count++;
    if (maxPrice != null) count++;
    if (minRating > 0) count++;
    if (maxDeliveryMinutes != null) count++;
    if (location != null) count++;
    return count;
  }

  RestaurantFilter copyWith({
    String? categoryId,
    double? maxPrice,
    double? minRating,
    int? maxDeliveryMinutes,
    String? location,
    SortOption? sort,
    bool clearCategory = false,
    bool clearPrice = false,
    bool clearDelivery = false,
    bool clearLocation = false,
  }) {
    return RestaurantFilter(
      categoryId: clearCategory ? null : (categoryId ?? this.categoryId),
      maxPrice: clearPrice ? null : (maxPrice ?? this.maxPrice),
      minRating: minRating ?? this.minRating,
      maxDeliveryMinutes: clearDelivery
          ? null
          : (maxDeliveryMinutes ?? this.maxDeliveryMinutes),
      location: clearLocation ? null : (location ?? this.location),
      sort: sort ?? this.sort,
    );
  }
}

/// Reads restaurants and dishes. It uses mock data, but the rest of the app
/// does not know that, so a real API could be plugged in here later.
class RestaurantService {
  RestaurantService._();

  /// Simulates a network request so we can show a loading indicator.
  static Future<List<Restaurant>> fetchRestaurants() async {
    await Future.delayed(const Duration(milliseconds: 800));
    return MockData.restaurants;
  }

  static Restaurant? findRestaurant(String id) {
    for (final restaurant in MockData.restaurants) {
      if (restaurant.id == id) return restaurant;
    }
    return null;
  }

  static FoodItem? findFood(String id) {
    for (final food in MockData.foods) {
      if (food.id == id) return food;
    }
    return null;
  }

  static List<FoodItem> menuFor(String restaurantId) =>
      MockData.foods.where((f) => f.restaurantId == restaurantId).toList();

  static List<Review> reviewsFor(String restaurantId) =>
      MockData.reviews.where((r) => r.restaurantId == restaurantId).toList();

  /// Categories a restaurant serves, worked out from its menu.
  static List<FoodCategory> categoriesFor(String restaurantId) {
    final ids = menuFor(restaurantId).map((f) => f.categoryId).toSet();
    return MockData.categories.where((c) => ids.contains(c.id)).toList();
  }

  /// Cheapest dish on the menu, used for price filtering and sorting.
  static double startingPrice(String restaurantId) {
    final menu = menuFor(restaurantId);
    if (menu.isEmpty) return 0;
    var cheapest = menu.first.price;
    for (final food in menu) {
      if (food.price < cheapest) cheapest = food.price;
    }
    return cheapest;
  }

  static bool _matchesText(String source, String query) =>
      source.toLowerCase().contains(query);

  // ---------------------------------------------------------------- Restaurants
  static List<Restaurant> searchRestaurants(
    String query,
    RestaurantFilter filter,
  ) {
    final q = query.trim().toLowerCase();
    final results = <Restaurant>[];

    for (final r in MockData.restaurants) {
      final menu = menuFor(r.id);
      final categories = categoriesFor(r.id);

      final matchesQuery = q.isEmpty ||
          _matchesText(r.name, q) ||
          _matchesText(r.location, q) ||
          _matchesText(r.description, q) ||
          r.tags.any((t) => _matchesText(t, q)) ||
          menu.any((f) => _matchesText(f.name, q)) ||
          categories.any((c) => _matchesText(c.name, q));
      if (!matchesQuery) continue;

      final categoryId = filter.categoryId;
      if (categoryId != null && !categories.any((c) => c.id == categoryId)) {
        continue;
      }
      if (filter.minRating > 0 && r.rating < filter.minRating) continue;

      final maxMinutes = filter.maxDeliveryMinutes;
      if (maxMinutes != null && r.deliveryMinutes > maxMinutes) continue;

      final location = filter.location;
      if (location != null && r.location != location) continue;

      final maxPrice = filter.maxPrice;
      if (maxPrice != null && startingPrice(r.id) > maxPrice) continue;

      results.add(r);
    }

    switch (filter.sort) {
      case SortOption.popular:
        results.sort((a, b) => b.popularity.compareTo(a.popularity));
      case SortOption.highestRated:
        results.sort((a, b) => b.rating.compareTo(a.rating));
      case SortOption.lowestPrice:
        results.sort(
            (a, b) => startingPrice(a.id).compareTo(startingPrice(b.id)));
      case SortOption.fastestDelivery:
        results.sort((a, b) => a.deliveryMinutes.compareTo(b.deliveryMinutes));
    }
    return results;
  }

  // --------------------------------------------------------------------- Dishes
  static List<FoodItem> searchFoods(String query, RestaurantFilter filter) {
    final q = query.trim().toLowerCase();
    final results = <FoodItem>[];

    for (final food in MockData.foods) {
      final restaurant = findRestaurant(food.restaurantId);
      if (restaurant == null) continue;
      final categoryName = MockData.categoryById(food.categoryId)?.name ?? '';

      final matchesQuery = q.isEmpty ||
          _matchesText(food.name, q) ||
          _matchesText(food.description, q) ||
          _matchesText(categoryName, q) ||
          _matchesText(restaurant.name, q) ||
          food.ingredients.any((i) => _matchesText(i, q));
      if (!matchesQuery) continue;

      final categoryId = filter.categoryId;
      if (categoryId != null && food.categoryId != categoryId) continue;

      final maxPrice = filter.maxPrice;
      if (maxPrice != null && food.price > maxPrice) continue;

      if (filter.minRating > 0 && food.rating < filter.minRating) continue;

      final maxMinutes = filter.maxDeliveryMinutes;
      if (maxMinutes != null && restaurant.deliveryMinutes > maxMinutes) {
        continue;
      }

      final location = filter.location;
      if (location != null && restaurant.location != location) continue;

      results.add(food);
    }

    switch (filter.sort) {
      case SortOption.popular:
        results.sort((a, b) {
          if (a.isPopular != b.isPopular) return a.isPopular ? -1 : 1;
          return b.rating.compareTo(a.rating);
        });
      case SortOption.highestRated:
        results.sort((a, b) => b.rating.compareTo(a.rating));
      case SortOption.lowestPrice:
        results.sort((a, b) => a.price.compareTo(b.price));
      case SortOption.fastestDelivery:
        results.sort((a, b) {
          final aMinutes = findRestaurant(a.restaurantId)?.deliveryMinutes ?? 99;
          final bMinutes = findRestaurant(b.restaurantId)?.deliveryMinutes ?? 99;
          return aMinutes.compareTo(bMinutes);
        });
    }
    return results;
  }
}
