import 'package:flutter/foundation.dart';

import '../constants/app_constants.dart';
import '../data/mock_data.dart';
import '../models/user.dart';
import '../services/storage_service.dart';

/// Handles login, registration, logout and the profile.
///
/// NOTE: this is a mock for a university project. Accounts are stored
/// locally with SharedPreferences. A real app must use a secure backend
/// and never store plain-text passwords.
class AuthProvider extends ChangeNotifier {
  final StorageService _storage = StorageService.instance;

  AppUser? _user;
  bool _isLoggedIn = false;

  AppUser? get user => _user;
  bool get isLoggedIn => _isLoggedIn && _user != null;

  Future<void> load() async {
    _isLoggedIn = _storage.getBool(StorageKeys.isLoggedIn) ?? false;
    final json = _storage.getJson(StorageKeys.currentUser);
    if (json is Map<String, dynamic>) _user = AppUser.fromJson(json);
    notifyListeners();
  }

  Map<String, dynamic> _accounts() {
    final data = _storage.getJson(StorageKeys.accounts);
    return data is Map<String, dynamic> ? data : <String, dynamic>{};
  }

  Future<void> _setUser(AppUser user) async {
    _user = user;
    _isLoggedIn = true;
    await _storage.setJson(StorageKeys.currentUser, user.toJson());
    await _storage.setBool(StorageKeys.isLoggedIn, true);
    notifyListeners();
  }

  /// Returns null on success, or an error message to show the user.
  Future<String?> login(String email, String password) async {
    await Future.delayed(const Duration(milliseconds: 900)); // Simulated network.
    final key = email.trim().toLowerCase();

    try {
      if (key == AppConstants.demoEmail && password == AppConstants.demoPassword) {
        // Keep any profile edits the demo user made earlier.
        final saved = _user;
        await _setUser(saved != null && saved.email == AppConstants.demoEmail
            ? saved
            : MockData.demoUser);
        return null;
      }

      final account = _accounts()[key];
      if (account is! Map<String, dynamic>) {
        return 'No account found for $key. Create one or use the demo account.';
      }
      if (account['password'] != password) {
        return 'Incorrect password. Please try again.';
      }
      final userJson = account['user'];
      if (userJson is! Map<String, dynamic>) {
        return 'This account could not be loaded. Please register again.';
      }
      await _setUser(AppUser.fromJson(userJson));
      return null;
    } catch (e) {
      return 'Login failed: $e';
    }
  }

  Future<String?> register({
    required String name,
    required String email,
    required String phone,
    required String area,
    required String password,
  }) async {
    await Future.delayed(const Duration(milliseconds: 900));
    final key = email.trim().toLowerCase();
    final accounts = _accounts();

    if (accounts.containsKey(key) || key == AppConstants.demoEmail) {
      return 'An account with this email already exists.';
    }

    final user = AppUser(
      name: name.trim(),
      email: key,
      phone: phone.trim(),
      area: area,
    );
    accounts[key] = {'password': password, 'user': user.toJson()};

    try {
      await _storage.setJson(StorageKeys.accounts, accounts);
      await _setUser(user);
      return null;
    } catch (e) {
      return 'Could not create your account: $e';
    }
  }

  Future<void> updateProfile(AppUser updated) async {
    _user = updated;
    notifyListeners();
    await _storage.setJson(StorageKeys.currentUser, updated.toJson());

    // Also update the saved account, if this is a registered user.
    final accounts = _accounts();
    final account = accounts[updated.email];
    if (account is Map<String, dynamic>) {
      account['user'] = updated.toJson();
      await _storage.setJson(StorageKeys.accounts, accounts);
    }
  }

  Future<void> updateArea(String area) async {
    final current = _user;
    if (current == null) return;
    await updateProfile(current.copyWith(area: area));
  }

  Future<void> logout() async {
    _isLoggedIn = false;
    notifyListeners();
    await _storage.setBool(StorageKeys.isLoggedIn, false);
  }
}
