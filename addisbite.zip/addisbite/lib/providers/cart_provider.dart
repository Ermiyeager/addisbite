import 'dart:math' as math;

import 'package:flutter/foundation.dart';

import '../constants/app_constants.dart';
import '../data/mock_data.dart';
import '../models/cart_item.dart';
import '../models/food_item.dart';
import '../models/order.dart';
import '../models/promo_code.dart';
import '../models/restaurant.dart';
import '../services/restaurant_service.dart';
import '../services/storage_service.dart';
import '../utils/formatters.dart';

enum AddToCartResult { added, differentRestaurant, restaurantClosed }

/// The shopping cart. All totals are calculated here with Dart,
/// nothing is hard-coded.
class CartProvider extends ChangeNotifier {
  final StorageService _storage = StorageService.instance;

  final List<CartItem> _items = [];
  PromoCode? _appliedPromo;

  List<CartItem> get items => List.unmodifiable(_items);
  bool get isEmpty => _items.isEmpty;
  PromoCode? get appliedPromo => _appliedPromo;

  int get itemCount {
    var count = 0;
    for (final item in _items) {
      count += item.quantity;
    }
    return count;
  }

  /// A cart can only contain food from one restaurant (like real apps).
  String? get restaurantId =>
      _items.isEmpty ? null : _items.first.food.restaurantId;

  Restaurant? get restaurant {
    final id = restaurantId;
    return id == null ? null : RestaurantService.findRestaurant(id);
  }

  double get subtotal =>
      _items.fold<double>(0, (sum, item) => sum + item.totalPrice);

  double get deliveryFee {
    if (_items.isEmpty) return 0;
    if (subtotal >= AppConstants.freeDeliveryThreshold) return 0;
    return restaurant?.deliveryFee ?? 0;
  }

  double get discount => _appliedPromo?.calculateDiscount(subtotal) ?? 0;

  double get total => math.max(0.0, subtotal + deliveryFee - discount);

  /// How much more the user must add to get free delivery.
  double get amountToFreeDelivery =>
      math.max(0.0, AppConstants.freeDeliveryThreshold - subtotal);

  // ---------------------------------------------------------------- Create
  AddToCartResult addItem(
    FoodItem food, {
    int quantity = 1,
    List<FoodExtra> extras = const [],
    String? note,
  }) {
    final foodRestaurant = RestaurantService.findRestaurant(food.restaurantId);
    if (foodRestaurant != null && !foodRestaurant.isOpen) {
      return AddToCartResult.restaurantClosed;
    }
    if (restaurantId != null && restaurantId != food.restaurantId) {
      return AddToCartResult.differentRestaurant;
    }

    final key = CartItem.buildKey(food.id, extras);
    final index = _items.indexWhere((item) => item.id == key);
    if (index >= 0) {
      _items[index].quantity += quantity; // Same dish + extras: merge lines.
    } else {
      _items.add(CartItem(
        id: key,
        food: food,
        quantity: quantity,
        selectedExtras: List.of(extras),
        note: (note == null || note.trim().isEmpty) ? null : note.trim(),
      ));
    }
    _saveAndNotify();
    return AddToCartResult.added;
  }

  /// Empties the cart and adds a dish from a different restaurant.
  void replaceCartWith(
    FoodItem food, {
    int quantity = 1,
    List<FoodExtra> extras = const [],
    String? note,
  }) {
    _items.clear();
    _appliedPromo = null;
    addItem(food, quantity: quantity, extras: extras, note: note);
  }

  // ---------------------------------------------------------------- Update
  void increment(String id) {
    final index = _items.indexWhere((item) => item.id == id);
    if (index < 0) return;
    _items[index].quantity++;
    _saveAndNotify();
  }

  void decrement(String id) {
    final index = _items.indexWhere((item) => item.id == id);
    if (index < 0) return;
    if (_items[index].quantity > 1) {
      _items[index].quantity--;
    } else {
      _items.removeAt(index);
    }
    _saveAndNotify();
  }

  // ---------------------------------------------------------------- Delete
  /// Removes a line and returns its old position (used for "Undo").
  int remove(String id) {
    final index = _items.indexWhere((item) => item.id == id);
    if (index >= 0) {
      _items.removeAt(index);
      _saveAndNotify();
    }
    return index;
  }

  void restore(CartItem item, int index) {
    _items.insert(math.min(math.max(index, 0), _items.length), item);
    _saveAndNotify();
  }

  void clear() {
    _items.clear();
    _appliedPromo = null;
    _saveAndNotify();
  }

  /// Replaces the cart with the items of a previous order.
  int reorder(Order order) {
    _items.clear();
    _appliedPromo = null;
    var added = 0;
    for (final item in order.items) {
      _items.add(item.copy());
      added += item.quantity;
    }
    _saveAndNotify();
    return added;
  }

  // ----------------------------------------------------------- Promo codes
  /// Returns null if the code was applied, otherwise an error message.
  String? applyPromo(String code) {
    final normalized = code.trim().toUpperCase();
    if (normalized.isEmpty) return 'Please enter a promo code.';

    PromoCode? promo;
    for (final candidate in MockData.promoCodes) {
      if (candidate.code == normalized) {
        promo = candidate;
        break;
      }
    }

    if (promo == null) return '"$normalized" is not a valid promo code.';
    if (_items.isEmpty) return 'Add some food first, then apply $normalized.';
    if (subtotal < promo.minOrder) {
      return 'Add ${formatBirr(promo.minOrder - subtotal)} more to use $normalized.';
    }

    _appliedPromo = promo;
    notifyListeners();
    return null;
  }

  void removePromo() {
    _appliedPromo = null;
    notifyListeners();
  }

  // ----------------------------------------------------------- Persistence
  void _saveAndNotify() {
    // Drop the promo if the cart no longer meets its minimum.
    final promo = _appliedPromo;
    if (promo != null && subtotal < promo.minOrder) _appliedPromo = null;

    notifyListeners();
    _storage.setJson(
        StorageKeys.cart, _items.map((item) => item.toJson()).toList());
  }

  Future<void> load() async {
    final data = _storage.getJson(StorageKeys.cart);
    _items.clear();
    if (data is List) {
      for (final raw in data) {
        if (raw is Map<String, dynamic>) {
          final item = CartItem.fromJson(raw, RestaurantService.findFood);
          if (item != null) _items.add(item);
        }
      }
    }
    notifyListeners();
  }
}
