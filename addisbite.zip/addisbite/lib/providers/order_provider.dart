import 'package:flutter/foundation.dart';

import '../constants/app_constants.dart';
import '../data/mock_data.dart';
import '../models/address.dart';
import '../models/cart_item.dart';
import '../models/order.dart';
import '../services/restaurant_service.dart';
import '../services/storage_service.dart';
import '../utils/formatters.dart';

/// Thrown when an order cannot be placed.
class OrderException implements Exception {
  final String message;
  const OrderException(this.message);

  @override
  String toString() => message;
}

class OrderProvider extends ChangeNotifier {
  final StorageService _storage = StorageService.instance;
  final List<Order> _orders = [];

  /// Newest first.
  List<Order> get orders {
    final sorted = [..._orders];
    sorted.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return sorted;
  }

  List<Order> get activeOrders => orders.where((o) => o.isActive).toList();
  List<Order> get pastOrders => orders.where((o) => !o.isActive).toList();

  double get totalSpent => _orders
      .where((o) => o.status == OrderStatus.delivered)
      .fold<double>(0, (sum, o) => sum + o.total);

  Order? findById(String id) {
    for (final order in _orders) {
      if (order.id == id) return order;
    }
    return null;
  }

  Future<void> load() async {
    final data = _storage.getJson(StorageKeys.orders);
    _orders.clear();
    if (data is List) {
      for (final raw in data) {
        if (raw is Map<String, dynamic>) {
          final order = Order.fromJson(raw, RestaurantService.findFood);
          if (order != null) _orders.add(order);
        }
      }
    } else {
      // First launch: add sample history so the screen is not empty.
      _orders.addAll(MockData.buildSampleOrders());
      await _save();
    }
    notifyListeners();
  }

  Future<void> _save() => _storage.setJson(
      StorageKeys.orders, _orders.map((o) => o.toJson()).toList());

  /// Creates and saves a new order. Throws [OrderException] on failure.
  Future<Order> placeOrder({
    required List<CartItem> items,
    required Address address,
    required PaymentMethod paymentMethod,
    required double subtotal,
    required double deliveryFee,
    required double discount,
    required double total,
    String? promoCode,
    DateTime? scheduledFor,
  }) async {
    // Simulate sending the order to a server.
    await Future.delayed(const Duration(seconds: 2));

    if (items.isEmpty) throw const OrderException('Your cart is empty.');

    final restaurant =
        RestaurantService.findRestaurant(items.first.food.restaurantId);
    if (restaurant == null) {
      throw const OrderException('This restaurant is no longer available.');
    }
    if (!restaurant.isOpen) {
      throw OrderException('${restaurant.name} is closed right now.');
    }

    final order = Order(
      id: generateOrderId(),
      restaurantId: restaurant.id,
      restaurantName: restaurant.name,
      items: items.map((item) => item.copy()).toList(),
      address: address,
      paymentMethod: paymentMethod,
      subtotal: subtotal,
      deliveryFee: deliveryFee,
      discount: discount,
      total: total,
      promoCode: promoCode,
      createdAt: DateTime.now(),
      scheduledFor: scheduledFor,
      etaMinutes: restaurant.deliveryMinutes + 10,
    );

    _orders.add(order);
    await _save();
    notifyListeners();
    return order;
  }

  /// Moves an active order to its next status (simulated tracking).
  void advanceStatus(String id) {
    final order = findById(id);
    if (order == null || !order.isActive) return;
    order.status = order.status.next;
    notifyListeners();
    _save();
  }

  Future<void> cancelOrder(String id) async {
    final order = findById(id);
    if (order == null || order.status != OrderStatus.confirmed) return;
    order.status = OrderStatus.cancelled;
    notifyListeners();
    await _save();
  }
}
