import 'package:flutter/foundation.dart';

import '../constants/app_constants.dart';
import '../data/mock_data.dart';
import '../models/food_item.dart';
import '../models/restaurant.dart';
import '../services/storage_service.dart';

/// Stores the ids of favourite restaurants and dishes.
class FavoritesProvider extends ChangeNotifier {
  final StorageService _storage = StorageService.instance;

  final Set<String> _restaurantIds = {};
  final Set<String> _foodIds = {};

  int get count => _restaurantIds.length + _foodIds.length;

  List<Restaurant> get favoriteRestaurants => MockData.restaurants
      .where((r) => _restaurantIds.contains(r.id))
      .toList();

  List<FoodItem> get favoriteFoods =>
      MockData.foods.where((f) => _foodIds.contains(f.id)).toList();

  bool isRestaurantFavorite(String id) => _restaurantIds.contains(id);
  bool isFoodFavorite(String id) => _foodIds.contains(id);

  Future<void> load() async {
    _restaurantIds
      ..clear()
      ..addAll(_storage.getStringList(StorageKeys.favoriteRestaurants) ?? []);
    _foodIds
      ..clear()
      ..addAll(_storage.getStringList(StorageKeys.favoriteFoods) ?? []);
    notifyListeners();
  }

  /// Returns true if the restaurant is now a favourite.
  bool toggleRestaurant(String id) {
    final added = _restaurantIds.add(id);
    if (!added) _restaurantIds.remove(id);
    notifyListeners();
    _storage.setStringList(
        StorageKeys.favoriteRestaurants, _restaurantIds.toList());
    return added;
  }

  /// Returns true if the dish is now a favourite.
  bool toggleFood(String id) {
    final added = _foodIds.add(id);
    if (!added) _foodIds.remove(id);
    notifyListeners();
    _storage.setStringList(StorageKeys.favoriteFoods, _foodIds.toList());
    return added;
  }
}
