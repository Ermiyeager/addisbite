import 'package:flutter/material.dart';

import '../constants/app_constants.dart';
import '../services/storage_service.dart';

/// Holds app settings: theme, notifications and language.
class SettingsProvider extends ChangeNotifier {
  final StorageService _storage = StorageService.instance;

  ThemeMode _themeMode = ThemeMode.light;
  bool _notificationsEnabled = true;
  String _language = AppConstants.languages.first;

  ThemeMode get themeMode => _themeMode;
  bool get isDarkMode => _themeMode == ThemeMode.dark;
  bool get notificationsEnabled => _notificationsEnabled;
  String get language => _language;

  Future<void> load() async {
    final dark = _storage.getBool(StorageKeys.darkMode) ?? false;
    _themeMode = dark ? ThemeMode.dark : ThemeMode.light;
    _notificationsEnabled = _storage.getBool(StorageKeys.notifications) ?? true;
    _language = _storage.getString(StorageKeys.language) ??
        AppConstants.languages.first;
    notifyListeners();
  }

  Future<void> setDarkMode(bool enabled) async {
    _themeMode = enabled ? ThemeMode.dark : ThemeMode.light;
    notifyListeners(); // The whole app rebuilds with the new theme.
    await _storage.setBool(StorageKeys.darkMode, enabled);
  }

  Future<void> setNotifications(bool enabled) async {
    _notificationsEnabled = enabled;
    notifyListeners();
    await _storage.setBool(StorageKeys.notifications, enabled);
  }

  Future<void> setLanguage(String language) async {
    _language = language;
    notifyListeners();
    await _storage.setString(StorageKeys.language, language);
  }
}
