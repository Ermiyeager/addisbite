/// Form validators. Each returns an error message, or null when valid.
class Validators {
  Validators._();

  static String? requiredField(String? value, [String field = 'This field']) {
    if (value == null || value.trim().isEmpty) return '$field is required';
    return null;
  }

  static String? name(String? value) {
    final error = requiredField(value, 'Name');
    if (error != null) return error;
    if (value!.trim().length < 3) return 'Name must be at least 3 characters';
    return null;
  }

  static String? email(String? value) {
    final error = requiredField(value, 'Email');
    if (error != null) return error;
    final pattern = RegExp(r'^[\w.+-]+@[\w-]+\.[\w.-]+$');
    if (!pattern.hasMatch(value!.trim())) return 'Enter a valid email address';
    return null;
  }

  static String? password(String? value) {
    final error = requiredField(value, 'Password');
    if (error != null) return error;
    if (value!.length < 6) return 'Password must be at least 6 characters';
    return null;
  }

  static String? confirmPassword(String? value, String original) {
    if (value == null || value.isEmpty) return 'Please confirm your password';
    if (value != original) return 'Passwords do not match';
    return null;
  }

  /// Accepts Ethiopian mobile numbers: 09XXXXXXXX, 07XXXXXXXX or +2519XXXXXXXX.
  static String? phone(String? value) {
    final error = requiredField(value, 'Phone number');
    if (error != null) return error;
    final cleaned = value!.replaceAll(RegExp(r'[\s-]'), '');
    final pattern = RegExp(r'^(\+251|0)(9|7)\d{8}$');
    if (!pattern.hasMatch(cleaned)) {
      return 'Enter a valid Ethiopian number, e.g. 0911 234 567';
    }
    return null;
  }

  static String? cardNumber(String? value) {
    final error = requiredField(value, 'Card number');
    if (error != null) return error;
    final digits = value!.replaceAll(RegExp(r'\s'), '');
    if (!RegExp(r'^\d{16}$').hasMatch(digits)) {
      return 'Card number must have 16 digits';
    }
    return null;
  }

  static String? promoCode(String? value) {
    if (value == null || value.trim().isEmpty) return 'Enter a promo code';
    if (!RegExp(r'^[A-Za-z0-9]{4,12}$').hasMatch(value.trim())) {
      return 'Codes use 4–12 letters or numbers';
    }
    return null;
  }
}
