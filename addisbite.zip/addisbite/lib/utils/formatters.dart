/// Formats a number as Ethiopian Birr, e.g. 1500 -> "1,500 ብር".
String formatBirr(double amount, {bool useCode = false}) {
  final rounded = amount.round();
  final digits = rounded.abs().toString();
  final buffer = StringBuffer();

  // Insert a comma every three digits from the right.
  for (var i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) buffer.write(',');
    buffer.write(digits[i]);
  }

  final sign = rounded < 0 ? '-' : '';
  return useCode ? '$sign$buffer ETB' : '$sign$buffer ብር';
}

const List<String> _months = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

String formatTime(DateTime date) {
  final hour = date.hour % 12 == 0 ? 12 : date.hour % 12;
  final minute = date.minute.toString().padLeft(2, '0');
  final period = date.hour < 12 ? 'AM' : 'PM';
  return '$hour:$minute $period';
}

/// e.g. "Sep 30, 2026"
String formatDate(DateTime date) =>
    '${_months[date.month - 1]} ${date.day}, ${date.year}';

/// e.g. "Sep 30, 2026 • 7:45 PM"
String formatDateTime(DateTime date) => '${formatDate(date)} • ${formatTime(date)}';

String greetingForNow() {
  final hour = DateTime.now().hour;
  if (hour < 12) return 'Good morning';
  if (hour < 17) return 'Good afternoon';
  return 'Good evening';
}

/// Creates an order id such as "AB-482913".
String generateOrderId() {
  final millis = DateTime.now().millisecondsSinceEpoch.toString();
  return 'AB-${millis.substring(millis.length - 6)}';
}
