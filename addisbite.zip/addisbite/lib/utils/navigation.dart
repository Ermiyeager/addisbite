import 'package:flutter/material.dart';

import '../models/food_item.dart';
import '../models/restaurant.dart';
import '../screens/food_details_screen.dart';
import '../screens/restaurant_details_screen.dart';

/// A custom page transition: fade + slight slide from the right.
Route<T> buildRoute<T>(Widget screen) {
  return PageRouteBuilder<T>(
    transitionDuration: const Duration(milliseconds: 350),
    reverseTransitionDuration: const Duration(milliseconds: 300),
    pageBuilder: (context, animation, secondaryAnimation) => screen,
    transitionsBuilder: (context, animation, secondaryAnimation, child) {
      final curved =
          CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.06, 0),
            end: Offset.zero,
          ).animate(curved),
          child: child,
        ),
      );
    },
  );
}

Future<T?> pushScreen<T>(BuildContext context, Widget screen) =>
    Navigator.of(context).push<T>(buildRoute<T>(screen));

/// Opens a restaurant. Passing the Restaurant object is an example of
/// "passing data between screens".
void openRestaurant(BuildContext context, Restaurant restaurant,
    {String? heroTag}) {
  pushScreen(
    context,
    RestaurantDetailsScreen(restaurant: restaurant, heroTag: heroTag),
  );
}

void openFood(BuildContext context, FoodItem food, {String? heroTag}) {
  pushScreen(context, FoodDetailsScreen(food: food, heroTag: heroTag));
}
