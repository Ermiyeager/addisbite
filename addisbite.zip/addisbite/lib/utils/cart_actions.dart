import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/food_item.dart';
import '../models/order.dart';
import '../providers/cart_provider.dart';
import '../screens/cart_screen.dart';
import '../services/restaurant_service.dart';
import 'navigation.dart';

/// Shared "add to cart" and "reorder" logic with dialogs and SnackBars,
/// so every screen behaves the same way.
class CartActions {
  CartActions._();

  static Future<void> addToCart(
    BuildContext context,
    FoodItem food, {
    int quantity = 1,
    List<FoodExtra> extras = const [],
    String? note,
  }) async {
    final cart = context.read<CartProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    final result =
        cart.addItem(food, quantity: quantity, extras: extras, note: note);

    switch (result) {
      case AddToCartResult.added:
        _showAdded(messenger, navigator, '$quantity× ${food.name} added to cart');
      case AddToCartResult.restaurantClosed:
        messenger
          ..hideCurrentSnackBar()
          ..showSnackBar(const SnackBar(
            content: Text('This restaurant is closed right now. Try again during opening hours.'),
          ));
      case AddToCartResult.differentRestaurant:
        final currentName = cart.restaurant?.name ?? 'another restaurant';
        final confirmed = await showDialog<bool>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: const Text('Start a new cart?'),
            content: Text(
              'Your cart has food from $currentName. '
              'Adding ${food.name} will remove those items.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, false),
                child: const Text('Keep cart'),
              ),
              TextButton(
                onPressed: () => Navigator.pop(dialogContext, true),
                child: const Text('Start new cart'),
              ),
            ],
          ),
        );
        if (confirmed == true) {
          cart.replaceCartWith(food,
              quantity: quantity, extras: extras, note: note);
          _showAdded(
              messenger, navigator, '$quantity× ${food.name} added to a new cart');
        }
    }
  }

  static Future<void> reorder(BuildContext context, Order order) async {
    final cart = context.read<CartProvider>();
    final messenger = ScaffoldMessenger.of(context);
    final navigator = Navigator.of(context);

    final restaurant = RestaurantService.findRestaurant(order.restaurantId);
    if (restaurant == null || !restaurant.isOpen) {
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(SnackBar(
          content: Text('${order.restaurantName} is closed, so this order cannot be repeated now.'),
        ));
      return;
    }

    if (!cart.isEmpty) {
      final confirmed = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: const Text('Replace your cart?'),
          content: const Text(
              'Reordering will replace the items currently in your cart.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, true),
              child: const Text('Replace'),
            ),
          ],
        ),
      );
      if (confirmed != true) return;
    }

    final added = cart.reorder(order);
    if (added == 0) {
      messenger.showSnackBar(const SnackBar(
          content: Text('These dishes are no longer on the menu.')));
      return;
    }
    _showAdded(
        messenger, navigator, '$added items from ${order.restaurantName} added to cart');
  }

  static void _showAdded(
    ScaffoldMessengerState messenger,
    NavigatorState navigator,
    String message,
  ) {
    messenger
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 3),
        action: SnackBarAction(
          label: 'View cart',
          onPressed: () => navigator.push(buildRoute(const CartScreen())),
        ),
      ));
  }
}
