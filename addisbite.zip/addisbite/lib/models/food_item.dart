/// An optional add-on for a dish, e.g. "Extra cheese +50 ብር".
class FoodExtra {
  final String name;
  final double price;

  const FoodExtra({required this.name, required this.price});

  Map<String, dynamic> toJson() => {'name': name, 'price': price};

  factory FoodExtra.fromJson(Map<String, dynamic> json) => FoodExtra(
        name: json['name'] as String? ?? 'Extra',
        price: (json['price'] as num?)?.toDouble() ?? 0,
      );

  // Two extras are equal if name and price match. This lets
  // List.contains() work when the user ticks/unticks extras.
  @override
  bool operator ==(Object other) =>
      other is FoodExtra && other.name == name && other.price == price;

  @override
  int get hashCode => Object.hash(name, price);
}

class FoodItem {
  final String id;
  final String restaurantId;
  final String name;
  final String description;
  final String emoji;
  final String categoryId;
  final double price;
  final double rating;
  final List<String> ingredients;
  final List<FoodExtra> extras;
  final bool isPopular;
  final bool isSpicy;
  final bool isVegetarian;
  final bool isEthiopian;

  const FoodItem({
    required this.id,
    required this.restaurantId,
    required this.name,
    required this.description,
    required this.emoji,
    required this.categoryId,
    required this.price,
    required this.rating,
    this.ingredients = const [],
    this.extras = const [],
    this.isPopular = false,
    this.isSpicy = false,
    this.isVegetarian = false,
    this.isEthiopian = false,
  });
}
