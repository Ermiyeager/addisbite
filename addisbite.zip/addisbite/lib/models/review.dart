class Review {
  final String id;
  final String restaurantId;
  final String userName;
  final double rating;
  final String comment;
  final DateTime date;

  const Review({
    required this.id,
    required this.restaurantId,
    required this.userName,
    required this.rating,
    required this.comment,
    required this.date,
  });
}
