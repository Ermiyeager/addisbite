class Address {
  final String fullName;
  final String phone;
  final String area;
  final String street;
  final String instructions;

  const Address({
    required this.fullName,
    required this.phone,
    required this.area,
    required this.street,
    this.instructions = '',
  });

  String get shortLabel => '$street, $area';

  Map<String, dynamic> toJson() => {
        'fullName': fullName,
        'phone': phone,
        'area': area,
        'street': street,
        'instructions': instructions,
      };

  factory Address.fromJson(Map<String, dynamic> json) => Address(
        fullName: json['fullName'] as String? ?? '',
        phone: json['phone'] as String? ?? '',
        area: json['area'] as String? ?? 'Bole',
        street: json['street'] as String? ?? '',
        instructions: json['instructions'] as String? ?? '',
      );
}
