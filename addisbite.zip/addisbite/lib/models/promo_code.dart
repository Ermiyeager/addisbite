import 'package:flutter/material.dart';

enum DiscountType { percentage, fixed }

class PromoCode {
  final String code;
  final String description;
  final DiscountType type;
  final double value;
  final double minOrder;
  final double? maxDiscount;

  const PromoCode({
    required this.code,
    required this.description,
    required this.type,
    required this.value,
    this.minOrder = 0,
    this.maxDiscount,
  });

  /// Returns how many birr this code takes off the given subtotal.
  double calculateDiscount(double subtotal) {
    if (subtotal < minOrder) return 0;

    double amount =
        type == DiscountType.percentage ? subtotal * value / 100 : value;

    final cap = maxDiscount;
    if (cap != null && amount > cap) amount = cap;

    // A discount can never be bigger than the order itself.
    return amount > subtotal ? subtotal : amount;
  }
}

/// A promotional banner shown on the home screen.
class PromoOffer {
  final String title;
  final String subtitle;
  final String emoji;
  final String? code;
  final List<Color> gradient;

  const PromoOffer({
    required this.title,
    required this.subtitle,
    required this.emoji,
    required this.gradient,
    this.code,
  });
}
