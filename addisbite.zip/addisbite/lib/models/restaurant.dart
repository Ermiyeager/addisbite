import 'package:flutter/material.dart';

/// The type of food a restaurant mainly serves.
enum CuisineType { ethiopian, international, fusion }

extension CuisineTypeLabel on CuisineType {
  String get label => switch (this) {
        CuisineType.ethiopian => 'Ethiopian',
        CuisineType.international => 'International',
        CuisineType.fusion => 'Ethiopian & International',
      };
}

class Restaurant {
  final String id;
  final String name;
  final String logoEmoji;
  final String coverEmoji;
  final String description;
  final String location;
  final double rating;
  final int reviewCount;
  final double deliveryFee;
  final int deliveryMinutes;
  final bool isOpen;
  final CuisineType cuisine;
  final List<String> tags;
  final List<Color> gradient;
  final int popularity;
  final String openingHours;

  const Restaurant({
    required this.id,
    required this.name,
    required this.logoEmoji,
    required this.coverEmoji,
    required this.description,
    required this.location,
    required this.rating,
    required this.reviewCount,
    required this.deliveryFee,
    required this.deliveryMinutes,
    required this.cuisine,
    required this.gradient,
    this.isOpen = true,
    this.tags = const [],
    this.popularity = 50,
    this.openingHours = '8:00 AM – 10:00 PM',
  });

  String get deliveryTimeLabel => '$deliveryMinutes–${deliveryMinutes + 10} min';

  bool get hasFreeDelivery => deliveryFee == 0;
}
