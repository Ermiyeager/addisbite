import 'package:flutter/material.dart';

import 'address.dart';
import 'cart_item.dart';
import 'food_item.dart';

enum OrderStatus {
  confirmed,
  preparing,
  driverAssigned,
  onTheWay,
  delivered,
  cancelled,
}

extension OrderStatusDetails on OrderStatus {
  /// The steps shown on the tracking screen, in order.
  static const List<OrderStatus> trackingSteps = [
    OrderStatus.confirmed,
    OrderStatus.preparing,
    OrderStatus.driverAssigned,
    OrderStatus.onTheWay,
    OrderStatus.delivered,
  ];

  String get label => switch (this) {
        OrderStatus.confirmed => 'Order confirmed',
        OrderStatus.preparing => 'Restaurant preparing',
        OrderStatus.driverAssigned => 'Driver assigned',
        OrderStatus.onTheWay => 'On the way',
        OrderStatus.delivered => 'Delivered',
        OrderStatus.cancelled => 'Cancelled',
      };

  String get description => switch (this) {
        OrderStatus.confirmed => 'The restaurant received your order.',
        OrderStatus.preparing => 'The kitchen is cooking your meal.',
        OrderStatus.driverAssigned => 'A rider is heading to the restaurant.',
        OrderStatus.onTheWay => 'Your food is riding through Addis.',
        OrderStatus.delivered => 'Enjoy your meal!',
        OrderStatus.cancelled => 'This order was cancelled.',
      };

  IconData get icon => switch (this) {
        OrderStatus.confirmed => Icons.receipt_long_rounded,
        OrderStatus.preparing => Icons.restaurant_rounded,
        OrderStatus.driverAssigned => Icons.person_pin_circle_rounded,
        OrderStatus.onTheWay => Icons.delivery_dining_rounded,
        OrderStatus.delivered => Icons.check_circle_rounded,
        OrderStatus.cancelled => Icons.cancel_rounded,
      };

  OrderStatus get next => switch (this) {
        OrderStatus.confirmed => OrderStatus.preparing,
        OrderStatus.preparing => OrderStatus.driverAssigned,
        OrderStatus.driverAssigned => OrderStatus.onTheWay,
        OrderStatus.onTheWay => OrderStatus.delivered,
        OrderStatus.delivered => OrderStatus.delivered,
        OrderStatus.cancelled => OrderStatus.cancelled,
      };
}

enum PaymentMethod { cash, telebirr, card }

extension PaymentMethodDetails on PaymentMethod {
  String get label => switch (this) {
        PaymentMethod.cash => 'Cash on delivery',
        PaymentMethod.telebirr => 'Telebirr',
        PaymentMethod.card => 'Bank / Card',
      };

  String get subtitle => switch (this) {
        PaymentMethod.cash => 'Pay the rider when your food arrives',
        PaymentMethod.telebirr => 'Pay from your Telebirr wallet',
        PaymentMethod.card => 'CBE, Awash, Dashen or any Visa card',
      };

  String get emoji => switch (this) {
        PaymentMethod.cash => '💵',
        PaymentMethod.telebirr => '📱',
        PaymentMethod.card => '💳',
      };
}

class Order {
  final String id;
  final String restaurantId;
  final String restaurantName;
  final List<CartItem> items;
  final Address address;
  final PaymentMethod paymentMethod;
  final double subtotal;
  final double deliveryFee;
  final double discount;
  final double total;
  final String? promoCode;
  final DateTime createdAt;
  final DateTime? scheduledFor;
  final int etaMinutes;
  OrderStatus status; // Not final: it changes while the order is tracked.

  Order({
    required this.id,
    required this.restaurantId,
    required this.restaurantName,
    required this.items,
    required this.address,
    required this.paymentMethod,
    required this.subtotal,
    required this.deliveryFee,
    required this.discount,
    required this.total,
    required this.createdAt,
    required this.etaMinutes,
    this.status = OrderStatus.confirmed,
    this.promoCode,
    this.scheduledFor,
  });

  bool get isActive =>
      status != OrderStatus.delivered && status != OrderStatus.cancelled;

  int get itemCount => items.fold<int>(0, (sum, item) => sum + item.quantity);

  String get itemsSummary =>
      items.map((item) => '${item.quantity}× ${item.food.name}').join(', ');

  Map<String, dynamic> toJson() => {
        'id': id,
        'restaurantId': restaurantId,
        'restaurantName': restaurantName,
        'items': items.map((item) => item.toJson()).toList(),
        'address': address.toJson(),
        'paymentMethod': paymentMethod.name,
        'subtotal': subtotal,
        'deliveryFee': deliveryFee,
        'discount': discount,
        'total': total,
        'promoCode': promoCode,
        'createdAt': createdAt.toIso8601String(),
        'scheduledFor': scheduledFor?.toIso8601String(),
        'etaMinutes': etaMinutes,
        'status': status.name,
      };

  /// Returns null (instead of crashing) if the saved data is corrupted.
  static Order? fromJson(
    Map<String, dynamic> json,
    FoodItem? Function(String id) findFood,
  ) {
    try {
      final items = <CartItem>[];
      final rawItems = json['items'];
      if (rawItems is List) {
        for (final raw in rawItems) {
          if (raw is Map<String, dynamic>) {
            final item = CartItem.fromJson(raw, findFood);
            if (item != null) items.add(item);
          }
        }
      }
      final scheduled = json['scheduledFor'] as String?;

      return Order(
        id: json['id'] as String,
        restaurantId: json['restaurantId'] as String,
        restaurantName: json['restaurantName'] as String? ?? 'Restaurant',
        items: items,
        address: Address.fromJson(json['address'] as Map<String, dynamic>),
        paymentMethod:
            PaymentMethod.values.byName(json['paymentMethod'] as String),
        subtotal: (json['subtotal'] as num).toDouble(),
        deliveryFee: (json['deliveryFee'] as num).toDouble(),
        discount: (json['discount'] as num).toDouble(),
        total: (json['total'] as num).toDouble(),
        promoCode: json['promoCode'] as String?,
        createdAt: DateTime.parse(json['createdAt'] as String),
        scheduledFor: scheduled == null ? null : DateTime.tryParse(scheduled),
        etaMinutes: (json['etaMinutes'] as num?)?.toInt() ?? 35,
        status: OrderStatus.values.byName(json['status'] as String),
      );
    } catch (e) {
      debugPrint('Skipping a corrupted saved order: $e');
      return null;
    }
  }
}
