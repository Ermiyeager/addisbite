import 'package:flutter/material.dart';

/// A food category such as "Ethiopian" or "Pizza".
/// Named FoodCategory because Flutter already has a class called Category.
class FoodCategory {
  final String id;
  final String name;
  final String emoji;
  final Color color;

  const FoodCategory({
    required this.id,
    required this.name,
    required this.emoji,
    required this.color,
  });
}
