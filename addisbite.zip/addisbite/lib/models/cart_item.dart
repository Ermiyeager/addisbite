import 'food_item.dart';

/// One line in the cart: a dish, its quantity and the chosen extras.
class CartItem {
  /// Unique key: the same dish with different extras is a separate line.
  final String id;
  final FoodItem food;
  int quantity;
  final List<FoodExtra> selectedExtras;
  final String? note;

  CartItem({
    required this.id,
    required this.food,
    this.quantity = 1,
    this.selectedExtras = const [],
    this.note,
  });

  static String buildKey(String foodId, List<FoodExtra> extras) {
    final names = extras.map((e) => e.name).toList()..sort();
    return '$foodId|${names.join(',')}';
  }

  double get extrasPrice =>
      selectedExtras.fold<double>(0, (sum, extra) => sum + extra.price);

  /// Price of one unit including extras.
  double get unitPrice => food.price + extrasPrice;

  /// Price of this whole line.
  double get totalPrice => unitPrice * quantity;

  CartItem copy() => CartItem(
        id: id,
        food: food,
        quantity: quantity,
        selectedExtras: List.of(selectedExtras),
        note: note,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'foodId': food.id,
        'quantity': quantity,
        'extras': selectedExtras.map((e) => e.toJson()).toList(),
        'note': note,
      };

  /// Rebuilds a cart item from JSON. Returns null if the dish no longer exists.
  static CartItem? fromJson(
    Map<String, dynamic> json,
    FoodItem? Function(String id) findFood,
  ) {
    final food = findFood(json['foodId'] as String? ?? '');
    if (food == null) return null;

    final extras = <FoodExtra>[];
    final rawExtras = json['extras'];
    if (rawExtras is List) {
      for (final raw in rawExtras) {
        if (raw is Map<String, dynamic>) extras.add(FoodExtra.fromJson(raw));
      }
    }

    return CartItem(
      id: json['id'] as String? ?? buildKey(food.id, extras),
      food: food,
      quantity: (json['quantity'] as num?)?.toInt() ?? 1,
      selectedExtras: extras,
      note: json['note'] as String?,
    );
  }
}
