/// The logged-in customer. Named AppUser to keep it clearly separate
/// from any "User" class a package might define.
class AppUser {
  final String name;
  final String email;
  final String phone;
  final String area;
  final String street;

  const AppUser({
    required this.name,
    required this.email,
    required this.phone,
    this.area = 'Bole',
    this.street = '',
  });

  String get firstName {
    final parts = name.trim().split(' ');
    return parts.isEmpty || parts.first.isEmpty ? 'Friend' : parts.first;
  }

  String get initials {
    final parts =
        name.trim().split(RegExp(r'\s+')).where((p) => p.isNotEmpty).toList();
    if (parts.isEmpty) return '?';
    if (parts.length == 1) return parts.first[0].toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }

  String get fullAddress =>
      street.isEmpty ? '$area, Addis Ababa' : '$street, $area, Addis Ababa';

  AppUser copyWith({
    String? name,
    String? email,
    String? phone,
    String? area,
    String? street,
  }) {
    return AppUser(
      name: name ?? this.name,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      area: area ?? this.area,
      street: street ?? this.street,
    );
  }

  Map<String, dynamic> toJson() => {
        'name': name,
        'email': email,
        'phone': phone,
        'area': area,
        'street': street,
      };

  factory AppUser.fromJson(Map<String, dynamic> json) => AppUser(
        name: json['name'] as String? ?? 'Guest',
        email: json['email'] as String? ?? '',
        phone: json['phone'] as String? ?? '',
        area: json['area'] as String? ?? 'Bole',
        street: json['street'] as String? ?? '',
      );
}
