import 'package:flutter/material.dart';

import '../constants/app_colors.dart';
import '../constants/app_constants.dart';
import '../models/address.dart';
import '../models/cart_item.dart';
import '../models/category.dart';
import '../models/food_item.dart';
import '../models/order.dart';
import '../models/promo_code.dart';
import '../models/restaurant.dart';
import '../models/review.dart';
import '../models/user.dart';

// Reusable lists of extras (top-level constants).
const List<FoodExtra> _injeraExtras = [
  FoodExtra(name: 'Extra injera', price: 20),
  FoodExtra(name: 'Extra awaze sauce', price: 30),
  FoodExtra(name: 'Extra meat', price: 100),
];

const List<FoodExtra> _cheeseExtras = [
  FoodExtra(name: 'Extra cheese', price: 50),
  FoodExtra(name: 'Extra sauce', price: 30),
  FoodExtra(name: 'Extra meat', price: 100),
];

const List<FoodExtra> _sideExtras = [
  FoodExtra(name: 'Side of fries', price: 80),
  FoodExtra(name: 'Extra sauce', price: 30),
  FoodExtra(name: 'Soft drink', price: 60),
];

const List<FoodExtra> _breakfastExtras = [
  FoodExtra(name: 'Extra honey', price: 25),
  FoodExtra(name: 'Extra kibe (spiced butter)', price: 40),
  FoodExtra(name: 'Macchiato', price: 50),
];

const List<FoodExtra> _dessertExtras = [
  FoodExtra(name: 'Scoop of ice cream', price: 60),
  FoodExtra(name: 'Chocolate sauce', price: 30),
];

const List<FoodExtra> _saladExtras = [
  FoodExtra(name: 'Grilled chicken', price: 120),
  FoodExtra(name: 'Avocado', price: 50),
  FoodExtra(name: 'Extra dressing', price: 20),
];

/// All mock data used by the app. In a real app this would come from an API.
class MockData {
  MockData._();

  static const AppUser demoUser = AppUser(
    name: 'Ermias Tesfaye',
    email: AppConstants.demoEmail,
    phone: '0911 234 567',
    area: 'Bole',
    street: 'Bole Medhanialem, House 214',
  );

  // ---------------------------------------------------------------- Categories
  static const List<FoodCategory> categories = [
    FoodCategory(id: 'ethiopian', name: 'Ethiopian', emoji: '🍲', color: AppColors.berbere),
    FoodCategory(id: 'breakfast', name: 'Breakfast', emoji: '🥞', color: Color(0xFFE39A1B)),
    FoodCategory(id: 'pizza', name: 'Pizza', emoji: '🍕', color: Color(0xFFE4572E)),
    FoodCategory(id: 'burgers', name: 'Burgers', emoji: '🍔', color: Color(0xFFB5651D)),
    FoodCategory(id: 'chicken', name: 'Chicken', emoji: '🍗', color: Color(0xFFD9822B)),
    FoodCategory(id: 'pasta', name: 'Pasta', emoji: '🍝', color: Color(0xFFC49A2C)),
    FoodCategory(id: 'grill', name: 'Grill', emoji: '🥩', color: Color(0xFF8C3B2E)),
    FoodCategory(id: 'sushi', name: 'Sushi', emoji: '🍣', color: Color(0xFF2E7DA8)),
    FoodCategory(id: 'street', name: 'Street food', emoji: '🌮', color: Color(0xFF6C8F2F)),
    FoodCategory(id: 'healthy', name: 'Salads', emoji: '🥗', color: AppColors.flagGreen),
    FoodCategory(id: 'desserts', name: 'Desserts', emoji: '🍰', color: Color(0xFFB8466E)),
  ];

  static FoodCategory? categoryById(String id) {
    for (final category in categories) {
      if (category.id == id) return category;
    }
    return null;
  }

  /// Two-colour gradient used behind a dish's emoji.
  static List<Color> gradientForCategory(String categoryId) {
    final base = categoryById(categoryId)?.color ?? AppColors.berbere;
    final light = Color.lerp(base, Colors.white, 0.35) ?? base;
    return [base, light];
  }

  // --------------------------------------------------------------- Restaurants
  static const List<Restaurant> restaurants = [
    Restaurant(
      id: 'r1',
      name: 'Habesha Taste',
      logoEmoji: '🏺',
      coverEmoji: '🍲',
      description:
          'Authentic Ethiopian dishes cooked the way grandma does: slow, spicy and generous.',
      location: 'Bole',
      rating: 4.8,
      reviewCount: 1240,
      deliveryFee: 40,
      deliveryMinutes: 30,
      cuisine: CuisineType.ethiopian,
      tags: ['Traditional', 'Injera', 'Family size'],
      gradient: [AppColors.berbereDeep, AppColors.berbereLight],
      popularity: 98,
    ),
    Restaurant(
      id: 'r2',
      name: 'Addis Traditional Kitchen',
      logoEmoji: '🧺',
      coverEmoji: '🍛',
      description:
          'A Piassa favourite since 1998, known for its tibs, bozena shiro and big mahberawi platters.',
      location: 'Piassa',
      rating: 4.7,
      reviewCount: 980,
      deliveryFee: 35,
      deliveryMinutes: 35,
      cuisine: CuisineType.ethiopian,
      tags: ['Tibs', 'Shiro', 'Fasting food'],
      gradient: [AppColors.buna, Color(0xFFB5651D)],
      popularity: 90,
    ),
    Restaurant(
      id: 'r3',
      name: 'Bole Bistro',
      logoEmoji: '🍽️',
      coverEmoji: '🍝',
      description:
          'Modern European bistro on Bole Road: fresh pasta, steaks, sushi rolls and desserts.',
      location: 'Bole',
      rating: 4.6,
      reviewCount: 760,
      deliveryFee: 60,
      deliveryMinutes: 40,
      cuisine: CuisineType.international,
      tags: ['Pasta', 'Steak', 'Sushi'],
      gradient: [Color(0xFF2F3E46), Color(0xFF52796F)],
      popularity: 80,
      openingHours: '11:00 AM – 11:00 PM',
    ),
    Restaurant(
      id: 'r4',
      name: 'Sheger Food House',
      logoEmoji: '☕',
      coverEmoji: '🥘',
      description:
          'Cosy Kazanchis café for fuul, firfir, sambusa and quick sandwiches with a good macchiato.',
      location: 'Kazanchis',
      rating: 4.5,
      reviewCount: 540,
      deliveryFee: 30,
      deliveryMinutes: 25,
      cuisine: CuisineType.fusion,
      tags: ['Breakfast', 'Snacks', 'Coffee'],
      gradient: [AppColors.flagGreen, Color(0xFF6BB38A)],
      popularity: 85,
      openingHours: '6:30 AM – 9:00 PM',
    ),
    Restaurant(
      id: 'r5',
      name: 'Merkato Grill',
      logoEmoji: '🔥',
      coverEmoji: '🍖',
      description:
          'Charcoal-grilled meat from the heart of Merkato: mixed tibs, T-bone and kuanta firfir.',
      location: 'Merkato',
      rating: 4.4,
      reviewCount: 610,
      deliveryFee: 45,
      deliveryMinutes: 35,
      cuisine: CuisineType.fusion,
      tags: ['Grill', 'Meat lovers'],
      gradient: [Color(0xFF7A2E22), AppColors.berbere],
      popularity: 75,
    ),
    Restaurant(
      id: 'r6',
      name: 'Addis Burger House',
      logoEmoji: '🍔',
      coverEmoji: '🍔',
      description:
          'Smash burgers, crispy fried chicken and golden fries near Megenagna roundabout.',
      location: 'Megenagna',
      rating: 4.6,
      reviewCount: 1510,
      deliveryFee: 50,
      deliveryMinutes: 20,
      cuisine: CuisineType.international,
      tags: ['Burgers', 'Fried chicken', 'Fast'],
      gradient: [Color(0xFFD9820F), AppColors.meskelGold],
      popularity: 96,
      openingHours: '10:00 AM – 12:00 AM',
    ),
    Restaurant(
      id: 'r7',
      name: 'Roma Pizza',
      logoEmoji: '🍕',
      coverEmoji: '🍕',
      description:
          'Wood-fired pizza in Mexico area, including our famous Habesha Special with awaze beef.',
      location: 'Mexico',
      rating: 4.5,
      reviewCount: 870,
      deliveryFee: 55,
      deliveryMinutes: 30,
      cuisine: CuisineType.international,
      tags: ['Pizza', 'Italian'],
      gradient: [Color(0xFFE4572E), Color(0xFFF3A712)],
      popularity: 88,
      openingHours: '11:00 AM – 11:00 PM',
    ),
    Restaurant(
      id: 'r8',
      name: 'Yeka Kitchen',
      logoEmoji: '🌿',
      coverEmoji: '🥞',
      description:
          'Healthy bowls, fresh salads and fluffy pancakes with a view of the Yeka hills.',
      location: 'Yeka',
      rating: 4.3,
      reviewCount: 320,
      deliveryFee: 35,
      deliveryMinutes: 45,
      cuisine: CuisineType.fusion,
      tags: ['Healthy', 'Brunch'],
      gradient: [Color(0xFF5E8A2E), Color(0xFFA7C47A)],
      isOpen: false, // Closed, to demonstrate the "restaurant closed" state.
      popularity: 60,
      openingHours: '7:00 AM – 3:00 PM',
    ),
    Restaurant(
      id: 'r9',
      name: 'Gerji Fusion Street',
      logoEmoji: '🌮',
      coverEmoji: '🍣',
      description:
          'Street-food energy from around the world: tacos, sushi rolls and grilled chicken salads.',
      location: 'Gerji',
      rating: 4.5,
      reviewCount: 430,
      deliveryFee: 0, // Free delivery.
      deliveryMinutes: 30,
      cuisine: CuisineType.international,
      tags: ['Tacos', 'Sushi', 'Free delivery'],
      gradient: [Color(0xFF6D2E46), Color(0xFFC4577A)],
      popularity: 70,
    ),
  ];

  // --------------------------------------------------------------------- Foods
  static const List<FoodItem> foods = [
    // Habesha Taste
    FoodItem(
      id: 'f1', restaurantId: 'r1', name: 'Doro Wat', emoji: '🍲', categoryId: 'ethiopian',
      price: 650, rating: 4.9, isPopular: true, isSpicy: true, isEthiopian: true,
      description: 'Slow-cooked chicken stew in berbere and kibe with a boiled egg, served on fresh injera.',
      ingredients: ['Chicken', 'Berbere', 'Red onion', 'Kibe', 'Boiled egg', 'Injera'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f2', restaurantId: 'r1', name: 'Special Kitfo', emoji: '🥩', categoryId: 'ethiopian',
      price: 720, rating: 4.8, isPopular: true, isEthiopian: true,
      description: 'Minced lean beef seasoned with mitmita and kibe, served with ayib and gomen.',
      ingredients: ['Beef', 'Mitmita', 'Kibe', 'Ayib', 'Gomen', 'Kocho'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f3', restaurantId: 'r1', name: 'Beyaynetu', emoji: '🍛', categoryId: 'ethiopian',
      price: 380, rating: 4.7, isPopular: true, isVegetarian: true, isEthiopian: true,
      description: 'A colourful fasting platter of misir, shiro, gomen and atkilt on injera.',
      ingredients: ['Misir', 'Shiro', 'Gomen', 'Atkilt', 'Injera'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f4', restaurantId: 'r1', name: 'Shiro Wat', emoji: '🥣', categoryId: 'ethiopian',
      price: 250, rating: 4.6, isVegetarian: true, isEthiopian: true,
      description: 'Smooth chickpea stew with garlic, onion and a touch of berbere.',
      ingredients: ['Chickpea flour', 'Garlic', 'Onion', 'Berbere', 'Oil'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f5', restaurantId: 'r1', name: 'Dulet', emoji: '🥘', categoryId: 'ethiopian',
      price: 420, rating: 4.5, isSpicy: true, isEthiopian: true,
      description: 'Minced tripe, liver and lean beef sautéed with kibe, mitmita and onion.',
      ingredients: ['Tripe', 'Liver', 'Beef', 'Kibe', 'Mitmita', 'Onion'],
      extras: _injeraExtras,
    ),
    // Addis Traditional Kitchen
    FoodItem(
      id: 'f6', restaurantId: 'r2', name: 'Derek Tibs', emoji: '🍖', categoryId: 'ethiopian',
      price: 580, rating: 4.8, isPopular: true, isSpicy: true, isEthiopian: true,
      description: 'Crispy fried beef cubes with rosemary, onion and green chilli.',
      ingredients: ['Beef', 'Rosemary', 'Onion', 'Green chilli', 'Kibe'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f7', restaurantId: 'r2', name: 'Bozena Shiro', emoji: '🍲', categoryId: 'ethiopian',
      price: 320, rating: 4.7, isEthiopian: true,
      description: 'Thick shiro simmered with tender beef, served bubbling hot in a clay pot.',
      ingredients: ['Shiro', 'Beef', 'Garlic', 'Kibe'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f8', restaurantId: 'r2', name: 'Injera Firfir', emoji: '🥙', categoryId: 'ethiopian',
      price: 220, rating: 4.5, isSpicy: true, isVegetarian: true, isEthiopian: true,
      description: 'Shredded injera tossed in a spicy berbere and onion sauce.',
      ingredients: ['Injera', 'Berbere', 'Onion', 'Tomato'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f9', restaurantId: 'r2', name: 'Chechebsa', emoji: '🍞', categoryId: 'breakfast',
      price: 200, rating: 4.6, isVegetarian: true, isEthiopian: true,
      description: 'Flaky kita flatbread torn and tossed in kibe and berbere, drizzled with honey.',
      ingredients: ['Kita bread', 'Kibe', 'Berbere', 'Honey'],
      extras: _breakfastExtras,
    ),
    FoodItem(
      id: 'f10', restaurantId: 'r2', name: 'Mahberawi Combo', emoji: '🍱', categoryId: 'ethiopian',
      price: 900, rating: 4.9, isPopular: true, isEthiopian: true,
      description: 'A sharing platter of kitfo, tibs, doro wat and shiro for friends and family.',
      ingredients: ['Kitfo', 'Tibs', 'Doro wat', 'Shiro', 'Injera'],
      extras: _injeraExtras,
    ),
    // Bole Bistro
    FoodItem(
      id: 'f11', restaurantId: 'r3', name: 'Fettuccine Alfredo', emoji: '🍝', categoryId: 'pasta',
      price: 480, rating: 4.6,
      description: 'Fresh fettuccine in a creamy parmesan and garlic sauce.',
      ingredients: ['Fettuccine', 'Cream', 'Parmesan', 'Garlic', 'Butter'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f12', restaurantId: 'r3', name: 'Grilled Beef Steak', emoji: '🥩', categoryId: 'grill',
      price: 950, rating: 4.7, isPopular: true,
      description: 'Tender beef steak with pepper sauce, grilled vegetables and mashed potato.',
      ingredients: ['Beef fillet', 'Pepper sauce', 'Vegetables', 'Potato'],
      extras: _sideExtras,
    ),
    FoodItem(
      id: 'f13', restaurantId: 'r3', name: 'Caesar Salad', emoji: '🥗', categoryId: 'healthy',
      price: 350, rating: 4.5,
      description: 'Crisp lettuce, croutons, parmesan and our house Caesar dressing.',
      ingredients: ['Lettuce', 'Croutons', 'Parmesan', 'Caesar dressing'],
      extras: _saladExtras,
    ),
    FoodItem(
      id: 'f14', restaurantId: 'r3', name: 'Chocolate Lava Cake', emoji: '🍫', categoryId: 'desserts',
      price: 280, rating: 4.8, isVegetarian: true,
      description: 'Warm chocolate cake with a molten centre.',
      ingredients: ['Dark chocolate', 'Butter', 'Eggs', 'Flour', 'Sugar'],
      extras: _dessertExtras,
    ),
    FoodItem(
      id: 'f15', restaurantId: 'r3', name: 'Salmon Sushi Roll', emoji: '🍣', categoryId: 'sushi',
      price: 850, rating: 4.6,
      description: 'Eight pieces of salmon and avocado maki with soy and wasabi.',
      ingredients: ['Sushi rice', 'Salmon', 'Avocado', 'Nori', 'Soy sauce'],
      extras: [FoodExtra(name: 'Extra wasabi', price: 20), FoodExtra(name: 'Extra ginger', price: 20)],
    ),
    // Sheger Food House
    FoodItem(
      id: 'f16', restaurantId: 'r4', name: 'Special Fuul', emoji: '🥘', categoryId: 'breakfast',
      price: 180, rating: 4.7, isPopular: true, isVegetarian: true, isEthiopian: true,
      description: 'Mashed fava beans with tomato, onion, green chilli, egg and fresh bread.',
      ingredients: ['Fava beans', 'Tomato', 'Onion', 'Green chilli', 'Egg', 'Bread'],
      extras: _breakfastExtras,
    ),
    FoodItem(
      id: 'f17', restaurantId: 'r4', name: 'Club Sandwich', emoji: '🥪', categoryId: 'street',
      price: 320, rating: 4.4,
      description: 'Triple-decker with chicken, egg, cheese, tomato and lettuce, served with fries.',
      ingredients: ['Toast', 'Chicken', 'Egg', 'Cheese', 'Tomato', 'Lettuce'],
      extras: _sideExtras,
    ),
    FoodItem(
      id: 'f18', restaurantId: 'r4', name: 'Lentil Sambusa (3 pcs)', emoji: '🥟', categoryId: 'street',
      price: 90, rating: 4.6, isPopular: true, isVegetarian: true, isEthiopian: true,
      description: 'Crispy pastry triangles filled with spiced lentils and green chilli.',
      ingredients: ['Pastry', 'Lentils', 'Onion', 'Green chilli'],
      extras: [FoodExtra(name: 'Extra sambusa', price: 30), FoodExtra(name: 'Awaze dip', price: 15)],
    ),
    FoodItem(
      id: 'f19', restaurantId: 'r4', name: 'Special Firfir', emoji: '🍛', categoryId: 'breakfast',
      price: 240, rating: 4.5, isSpicy: true, isEthiopian: true,
      description: 'Firfir with scrambled egg, ayib and a dash of awaze.',
      ingredients: ['Injera', 'Egg', 'Ayib', 'Awaze', 'Kibe'],
      extras: _breakfastExtras,
    ),
    // Merkato Grill
    FoodItem(
      id: 'f20', restaurantId: 'r5', name: 'Mixed Grill Tibs', emoji: '🍖', categoryId: 'grill',
      price: 680, rating: 4.7, isPopular: true, isSpicy: true, isEthiopian: true,
      description: 'Beef and lamb tibs sizzling on a hot plate with awaze and injera.',
      ingredients: ['Beef', 'Lamb', 'Awaze', 'Onion', 'Rosemary', 'Injera'],
      extras: _injeraExtras,
    ),
    FoodItem(
      id: 'f21', restaurantId: 'r5', name: 'T-Bone Steak', emoji: '🥩', categoryId: 'grill',
      price: 1100, rating: 4.6,
      description: 'A 400 g T-bone grilled over charcoal, with fries and salad.',
      ingredients: ['T-bone', 'Garlic butter', 'Fries', 'Salad'],
      extras: _sideExtras,
    ),
    FoodItem(
      id: 'f22', restaurantId: 'r5', name: 'Loaded Fries', emoji: '🍟', categoryId: 'street',
      price: 220, rating: 4.4,
      description: 'Crispy fries topped with melted cheese, minced beef and jalapeño.',
      ingredients: ['Potatoes', 'Cheese', 'Minced beef', 'Jalapeño'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f23', restaurantId: 'r5', name: 'Kuanta Firfir', emoji: '🥘', categoryId: 'ethiopian',
      price: 300, rating: 4.6, isSpicy: true, isEthiopian: true,
      description: 'Sun-dried beef (kuanta) cooked with injera, berbere and kibe.',
      ingredients: ['Kuanta', 'Injera', 'Berbere', 'Kibe'],
      extras: _injeraExtras,
    ),
    // Addis Burger House
    FoodItem(
      id: 'f24', restaurantId: 'r6', name: 'Classic Beef Burger', emoji: '🍔', categoryId: 'burgers',
      price: 420, rating: 4.6, isPopular: true,
      description: 'Juicy beef patty with lettuce, tomato, pickles and house sauce.',
      ingredients: ['Beef patty', 'Bun', 'Lettuce', 'Tomato', 'Pickles'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f25', restaurantId: 'r6', name: 'Double Cheese Burger', emoji: '🍔', categoryId: 'burgers',
      price: 580, rating: 4.8, isPopular: true,
      description: 'Two smashed patties, double cheddar, caramelised onion and burger sauce.',
      ingredients: ['2 beef patties', 'Cheddar', 'Onion', 'Bun'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f26', restaurantId: 'r6', name: 'Crispy Fried Chicken', emoji: '🍗', categoryId: 'chicken',
      price: 480, rating: 4.7, isPopular: true,
      description: 'Four pieces of golden fried chicken with a mitmita-spiced crust.',
      ingredients: ['Chicken', 'Flour', 'Mitmita', 'Garlic'],
      extras: _sideExtras,
    ),
    FoodItem(
      id: 'f27', restaurantId: 'r6', name: 'French Fries', emoji: '🍟', categoryId: 'street',
      price: 150, rating: 4.5, isVegetarian: true,
      description: 'Golden, crispy fries with ketchup.',
      ingredients: ['Potatoes', 'Salt', 'Ketchup'],
      extras: [FoodExtra(name: 'Cheese sauce', price: 40), FoodExtra(name: 'Large size', price: 50)],
    ),
    FoodItem(
      id: 'f28', restaurantId: 'r6', name: 'Spicy Chicken Burger', emoji: '🍔', categoryId: 'burgers',
      price: 450, rating: 4.5, isSpicy: true,
      description: 'Crispy chicken fillet with awaze mayo and coleslaw.',
      ingredients: ['Chicken fillet', 'Awaze mayo', 'Coleslaw', 'Bun'],
      extras: _cheeseExtras,
    ),
    // Roma Pizza
    FoodItem(
      id: 'f29', restaurantId: 'r7', name: 'Margherita Pizza', emoji: '🍕', categoryId: 'pizza',
      price: 520, rating: 4.6, isVegetarian: true,
      description: 'Tomato sauce, fresh mozzarella and basil on a thin crust.',
      ingredients: ['Dough', 'Tomato sauce', 'Mozzarella', 'Basil'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f30', restaurantId: 'r7', name: 'Pepperoni Pizza', emoji: '🍕', categoryId: 'pizza',
      price: 650, rating: 4.7, isPopular: true,
      description: 'Loaded with beef pepperoni and mozzarella.',
      ingredients: ['Dough', 'Tomato sauce', 'Mozzarella', 'Beef pepperoni'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f31', restaurantId: 'r7', name: 'Habesha Special Pizza', emoji: '🍕', categoryId: 'pizza',
      price: 700, rating: 4.8, isPopular: true, isSpicy: true,
      description: 'Our signature pizza: awaze-marinated beef, jalapeño and mitmita.',
      ingredients: ['Dough', 'Awaze beef', 'Mozzarella', 'Jalapeño', 'Mitmita'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f32', restaurantId: 'r7', name: 'Spaghetti Bolognese', emoji: '🍝', categoryId: 'pasta',
      price: 420, rating: 4.5,
      description: 'Spaghetti with a slow-cooked beef and tomato ragù.',
      ingredients: ['Spaghetti', 'Minced beef', 'Tomato', 'Parmesan'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f33', restaurantId: 'r7', name: 'Tiramisu', emoji: '🍮', categoryId: 'desserts',
      price: 260, rating: 4.6, isVegetarian: true,
      description: 'Layers of mascarpone and biscuits soaked in Ethiopian coffee.',
      ingredients: ['Mascarpone', 'Ladyfingers', 'Ethiopian coffee', 'Cocoa'],
      extras: _dessertExtras,
    ),
    // Yeka Kitchen (closed)
    FoodItem(
      id: 'f34', restaurantId: 'r8', name: 'Fluffy Pancakes', emoji: '🥞', categoryId: 'breakfast',
      price: 280, rating: 4.6, isVegetarian: true,
      description: 'Three thick pancakes with honey, butter and fresh fruit.',
      ingredients: ['Flour', 'Eggs', 'Milk', 'Honey', 'Fruit'],
      extras: _breakfastExtras,
    ),
    FoodItem(
      id: 'f35', restaurantId: 'r8', name: 'Avocado Salad', emoji: '🥑', categoryId: 'healthy',
      price: 260, rating: 4.5, isVegetarian: true,
      description: 'Avocado, tomato, onion and green chilli with lime.',
      ingredients: ['Avocado', 'Tomato', 'Onion', 'Lime'],
      extras: _saladExtras,
    ),
    FoodItem(
      id: 'f36', restaurantId: 'r8', name: 'Fresh Fruit Salad', emoji: '🍓', categoryId: 'desserts',
      price: 200, rating: 4.4, isVegetarian: true,
      description: 'Mango, papaya, banana and strawberries with a honey drizzle.',
      ingredients: ['Mango', 'Papaya', 'Banana', 'Strawberry', 'Honey'],
      extras: _dessertExtras,
    ),
    FoodItem(
      id: 'f37', restaurantId: 'r8', name: 'Honey Chechebsa', emoji: '🍞', categoryId: 'breakfast',
      price: 230, rating: 4.7, isVegetarian: true, isEthiopian: true,
      description: 'Chechebsa with extra honey and a side of yoghurt.',
      ingredients: ['Kita bread', 'Kibe', 'Honey', 'Yoghurt'],
      extras: _breakfastExtras,
    ),
    // Gerji Fusion Street
    FoodItem(
      id: 'f38', restaurantId: 'r9', name: 'Beef Tacos', emoji: '🌮', categoryId: 'street',
      price: 380, rating: 4.6, isSpicy: true,
      description: 'Three soft tacos with seasoned beef, salsa and cheese.',
      ingredients: ['Tortilla', 'Beef', 'Salsa', 'Cheese', 'Lettuce'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f39', restaurantId: 'r9', name: 'Chicken Tacos', emoji: '🌮', categoryId: 'street',
      price: 360, rating: 4.5,
      description: 'Grilled chicken tacos with avocado cream.',
      ingredients: ['Tortilla', 'Chicken', 'Avocado cream', 'Onion'],
      extras: _cheeseExtras,
    ),
    FoodItem(
      id: 'f40', restaurantId: 'r9', name: 'California Roll', emoji: '🍣', categoryId: 'sushi',
      price: 780, rating: 4.5,
      description: 'Crab stick, avocado and cucumber roll with sesame.',
      ingredients: ['Sushi rice', 'Crab stick', 'Avocado', 'Cucumber', 'Sesame'],
      extras: [FoodExtra(name: 'Extra wasabi', price: 20), FoodExtra(name: 'Spicy mayo', price: 30)],
    ),
    FoodItem(
      id: 'f41', restaurantId: 'r9', name: 'Grilled Chicken Salad', emoji: '🥗', categoryId: 'healthy',
      price: 340, rating: 4.6,
      description: 'Grilled chicken, mixed greens, tomato and honey-mustard dressing.',
      ingredients: ['Chicken', 'Mixed greens', 'Tomato', 'Honey mustard'],
      extras: _saladExtras,
    ),
  ];

  // --------------------------------------------------------------- Promo codes
  static const List<PromoCode> promoCodes = [
    PromoCode(
      code: 'ADDIS10',
      description: '10% off your order (up to 150 ብር)',
      type: DiscountType.percentage,
      value: 10,
      maxDiscount: 150,
    ),
    PromoCode(
      code: 'WELCOME50',
      description: '50 ብር off orders above 200 ብር',
      type: DiscountType.fixed,
      value: 50,
      minOrder: 200,
    ),
    PromoCode(
      code: 'HABESHA20',
      description: '20% off orders above 500 ብር (up to 300 ብር)',
      type: DiscountType.percentage,
      value: 20,
      minOrder: 500,
      maxDiscount: 300,
    ),
    PromoCode(
      code: 'BITE100',
      description: '100 ብር off orders above 1,000 ብር',
      type: DiscountType.fixed,
      value: 100,
      minOrder: 1000,
    ),
  ];

  static const List<PromoOffer> offers = [
    PromoOffer(
      title: 'Welcome to AddisBite',
      subtitle: 'Get 50 ብር off your first order',
      emoji: '🎉',
      code: 'WELCOME50',
      gradient: [AppColors.berbereDeep, AppColors.berbereLight],
    ),
    PromoOffer(
      title: 'Habesha feast week',
      subtitle: '20% off Ethiopian orders above 500 ብር',
      emoji: '🍲',
      code: 'HABESHA20',
      gradient: [AppColors.flagGreen, AppColors.flagGreenLight],
    ),
    PromoOffer(
      title: 'Addis deal',
      subtitle: '10% off anything, any restaurant',
      emoji: '🛵',
      code: 'ADDIS10',
      gradient: [Color(0xFFB8680A), AppColors.meskelGold],
    ),
    PromoOffer(
      title: 'Free delivery',
      subtitle: 'On every order above 1,500 ብር',
      emoji: '🚚',
      gradient: [AppColors.buna, Color(0xFF9C6644)],
    ),
  ];

  // ------------------------------------------------------------------- Reviews
  static final List<Review> reviews = [
    Review(id: 'v1', restaurantId: 'r1', userName: 'Hanna G.', rating: 5, comment: 'The doro wat tastes like holiday at home. Arrived hot!', date: DateTime(2026, 9, 21)),
    Review(id: 'v2', restaurantId: 'r1', userName: 'Samuel K.', rating: 4.5, comment: 'Kitfo was perfect, maybe a bit more mitmita next time.', date: DateTime(2026, 9, 14)),
    Review(id: 'v3', restaurantId: 'r2', userName: 'Meron A.', rating: 5, comment: 'Best bozena shiro in Addis, no discussion.', date: DateTime(2026, 9, 18)),
    Review(id: 'v4', restaurantId: 'r2', userName: 'Yonas T.', rating: 4.5, comment: 'Mahberawi combo fed four of us easily.', date: DateTime(2026, 8, 30)),
    Review(id: 'v5', restaurantId: 'r3', userName: 'Liya M.', rating: 4.5, comment: 'Steak was cooked exactly how I asked.', date: DateTime(2026, 9, 10)),
    Review(id: 'v6', restaurantId: 'r4', userName: 'Abel D.', rating: 4.5, comment: 'My go-to fuul before work in Kazanchis.', date: DateTime(2026, 9, 25)),
    Review(id: 'v7', restaurantId: 'r5', userName: 'Selam B.', rating: 4, comment: 'Mixed tibs were great, delivery took a little longer.', date: DateTime(2026, 9, 5)),
    Review(id: 'v8', restaurantId: 'r6', userName: 'Nahom W.', rating: 5, comment: 'Double cheese burger is dangerous. Ordering again.', date: DateTime(2026, 9, 27)),
    Review(id: 'v9', restaurantId: 'r6', userName: 'Bethlehem S.', rating: 4.5, comment: 'Fried chicken with mitmita crust is genius.', date: DateTime(2026, 9, 2)),
    Review(id: 'v10', restaurantId: 'r7', userName: 'Kaleb F.', rating: 5, comment: 'Habesha Special pizza is a must try.', date: DateTime(2026, 9, 19)),
    Review(id: 'v11', restaurantId: 'r8', userName: 'Ruth H.', rating: 4, comment: 'Lovely pancakes, wish they opened later.', date: DateTime(2026, 8, 22)),
    Review(id: 'v12', restaurantId: 'r9', userName: 'Dawit L.', rating: 4.5, comment: 'Free delivery and the tacos were fresh.', date: DateTime(2026, 9, 23)),
  ];

  // ------------------------------------------------------------- Sample orders
  /// Builds 10 past orders so the order history is not empty on first launch.
  /// Uses loops and calculations instead of hard-coded totals.
  static List<Order> buildSampleOrders() {
    final orders = <Order>[];
    final now = DateTime.now();
    final openRestaurants = restaurants.where((r) => r.isOpen).toList();

    for (var i = 0; i < 10; i++) {
      final restaurant = openRestaurants[i % openRestaurants.length];
      final menu = foods.where((f) => f.restaurantId == restaurant.id).toList();
      if (menu.isEmpty) continue;

      final items = <CartItem>[];
      final dishCount = 1 + (i % 2);
      for (var j = 0; j < dishCount && j < menu.length; j++) {
        final food = menu[(i + j) % menu.length];
        items.add(CartItem(
          id: CartItem.buildKey(food.id, const []),
          food: food,
          quantity: 1 + (j % 2),
        ));
      }

      final subtotal =
          items.fold<double>(0, (sum, item) => sum + item.totalPrice);
      final fee = restaurant.deliveryFee;

      orders.add(Order(
        id: 'AB-${240100 + i * 37}',
        restaurantId: restaurant.id,
        restaurantName: restaurant.name,
        items: items,
        address: Address(
          fullName: demoUser.name,
          phone: demoUser.phone,
          area: AppConstants.addisAreas[i % AppConstants.addisAreas.length],
          street: 'House ${10 + i}',
        ),
        paymentMethod: PaymentMethod.values[i % PaymentMethod.values.length],
        subtotal: subtotal,
        deliveryFee: fee,
        discount: 0,
        total: subtotal + fee,
        createdAt: now.subtract(Duration(days: i * 3 + 1, hours: i * 2)),
        etaMinutes: restaurant.deliveryMinutes,
        status: i == 3 ? OrderStatus.cancelled : OrderStatus.delivered,
      ));
    }
    return orders;
  }
}
