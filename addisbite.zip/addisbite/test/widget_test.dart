// Unit tests for AddisBite's pure Dart logic.
// Run with:  flutter test
import 'package:addisbite/models/promo_code.dart';
import 'package:addisbite/utils/formatters.dart';
import 'package:addisbite/utils/validators.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('formatBirr', () {
    test('adds thousands separators', () {
      expect(formatBirr(1500), '1,500 ብር');
      expect(formatBirr(250), '250 ብር');
      expect(formatBirr(1234567), '1,234,567 ብር');
    });
  });

  group('PromoCode', () {
    const addis10 = PromoCode(
      code: 'ADDIS10',
      description: '10% off',
      type: DiscountType.percentage,
      value: 10,
      maxDiscount: 150,
    );
    const welcome50 = PromoCode(
      code: 'WELCOME50',
      description: '50 off',
      type: DiscountType.fixed,
      value: 50,
      minOrder: 200,
    );

    test('percentage discount is capped', () {
      expect(addis10.calculateDiscount(500), 50);
      expect(addis10.calculateDiscount(3000), 150);
    });

    test('fixed discount needs a minimum order', () {
      expect(welcome50.calculateDiscount(150), 0);
      expect(welcome50.calculateDiscount(400), 50);
    });
  });

  group('Validators', () {
    test('Ethiopian phone numbers', () {
      expect(Validators.phone('0911 234 567'), isNull);
      expect(Validators.phone('+251911234567'), isNull);
      expect(Validators.phone('12345'), isNotNull);
    });

    test('email', () {
      expect(Validators.email('ermias@addisbite.et'), isNull);
      expect(Validators.email('not-an-email'), isNotNull);
    });
  });
}
